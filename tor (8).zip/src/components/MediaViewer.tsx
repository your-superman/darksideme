"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Check, Download, ExternalLink, FileDown, Images, Loader2, Trash2, X,
} from "lucide-react";
import {
  downloadToGallery, formatBytes, galleryDelete, galleryFindBySource,
  type GalleryRecord, type MediaKind,
} from "@/lib/galleryStore";
import { displayHost, shortOnion } from "@/lib/directory";
import type { MediaPreview } from "./types";

export interface ViewerItem {
  url: string; // original source URL
  kind: MediaKind;
  name?: string;
  pageUrl?: string;
  linkUrl?: string | null;
  // local gallery mode
  recordId?: string;
  blobUrl?: string;
  size?: number;
  createdAt?: number;
  mime?: string;
}

interface Props {
  item: ViewerItem;
  cc: string;
  device: string;
  onClose: () => void;
  onSaved: (rec: GalleryRecord) => void;
  onDeleted: (id: string) => void;
  onOpen: (url: string, newTab?: boolean) => void;
  onOpenGallery: () => void;
  toast: (title: string, body?: string, tone?: "green" | "violet" | "red") => void;
}

const ALBUM_LABEL: Record<MediaKind, string> = { image: "Images album", video: "Videos album", gif: "GIFs album" };

export default function MediaViewer(p: Props) {
  const isLocal = Boolean(p.item.recordId && p.item.blobUrl);
  const [name, setName] = useState(p.item.name || "");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);
  const [savedId, setSavedId] = useState<string | null>(p.item.recordId || null);
  const [error, setError] = useState("");

  const previewSrc = useMemo(() => {
    if (isLocal) return p.item.blobUrl as string;
    return `/api/proxy?url=${encodeURIComponent(p.item.url)}&cc=${p.cc}${p.device === "android" ? "&device=android" : ""}`;
  }, [isLocal, p.item.blobUrl, p.item.url, p.cc, p.device]);

  useEffect(() => {
    const fn = (e: KeyboardEvent) => e.key === "Escape" && p.onClose();
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [p]);

  useEffect(() => {
    if (isLocal) return;
    galleryFindBySource(p.item.url).then((found) => {
      if (found) setSavedId(found.id);
    }).catch(() => {});
  }, [isLocal, p.item.url]);

  const download = async () => {
    setBusy(true);
    setError("");
    setProgress(0);
    try {
      const rec = await downloadToGallery(p.item.url, {
        cc: p.cc,
        device: p.device,
        pageUrl: p.item.pageUrl,
        name: name.trim() || undefined,
        kindHint: p.item.kind,
        onProgress: (pr) => setProgress(pr),
      });
      setSavedId(rec.id);
      p.onSaved(rec);
      p.toast("Saved to your Gallery", `“${rec.name}” → ${ALBUM_LABEL[rec.kind]} · ${formatBytes(rec.size)}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Download failed. The site may be blocking downloads or went offline.");
    } finally {
      setBusy(false);
      setProgress(null);
    }
  };

  const remove = async () => {
    if (!p.item.recordId) return;
    await galleryDelete(p.item.recordId);
    p.onDeleted(p.item.recordId);
    p.toast("Removed from Gallery", undefined, "violet");
    p.onClose();
  };

  const exportToDevice = () => {
    if (!p.item.blobUrl) return;
    const a = document.createElement("a");
    a.href = p.item.blobUrl;
    a.download = p.item.name || "freeonion-media";
    a.click();
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-end justify-center bg-black/85 backdrop-blur-sm sm:items-center" onClick={p.onClose}>
      <div
        className="rise flex max-h-[94dvh] w-full max-w-2xl flex-col overflow-hidden rounded-t-3xl border border-[#1d5c2c] bg-[#040805] shadow-[0_0_60px_rgba(0,255,65,0.2)] sm:rounded-3xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* header */}
        <div className="flex items-center gap-2 border-b border-[#12351a] px-4 py-3">
          <span className={`rounded-full px-2.5 py-1 font-mono text-[10px] font-extrabold tracking-wider ${p.item.kind === "gif" ? "bg-[#9d00ff]/25 text-[#b26bff]" : p.item.kind === "video" ? "bg-[#00ff41]/15 text-[#00ff41]" : "bg-[#00ff41]/15 text-[#00ff41]"}`}>
            {p.item.kind.toUpperCase()} · {ALBUM_LABEL[p.item.kind]}
          </span>
          <span className="min-w-0 flex-1 truncate font-mono text-[11px] text-[#7fae8a]">{shortOnion(displayHost(p.item.url))}</span>
          <button onClick={p.onClose} className="rounded-lg border border-[#12351a] p-1.5 text-[#7fae8a] hover:text-white">
            <X size={15} />
          </button>
        </div>

        {/* media */}
        <div className="relative flex min-h-[220px] items-center justify-center overflow-hidden bg-black">
          {p.item.kind === "video" ? (
            <video key={previewSrc} src={previewSrc} controls autoPlay playsInline loop={false} className="max-h-[52dvh] w-full bg-black object-contain" />
          ) : (
            // eslint-disable-next-line @next/next/no-img-element
            <img key={previewSrc} src={previewSrc} alt={name || "media preview"} className="max-h-[52dvh] w-auto max-w-full object-contain" />
          )}
          {busy && progress !== null && (
            <div className="absolute inset-x-0 bottom-0 h-1.5 bg-black/60">
              <div className="h-full bg-gradient-to-r from-[#9d00ff] to-[#00ff41] transition-[width] duration-200" style={{ width: `${Math.round(progress * 100)}%` }} />
            </div>
          )}
        </div>

        {/* body */}
        <div className="space-y-3 overflow-y-auto px-4 py-4">
          {!isLocal ? (
            <>
              <div>
                <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-[0.16em] text-[#7fae8a]">Save with a name</label>
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Name this media…"
                  className="w-full rounded-xl border border-[#1d5c2c] bg-black/60 px-3 py-2.5 text-sm text-[#eaffef] outline-none placeholder:text-[#51755c] focus:border-[#00ff41] focus:shadow-[0_0_12px_rgba(0,255,65,0.25)]"
                />
              </div>

              {error && <p className="rounded-xl border border-[#ff5c7a]/50 bg-[#ff5c7a]/5 px-3 py-2 text-xs leading-relaxed text-[#ffb3c1]">{error}</p>}

              {savedId ? (
                <div className="flex gap-2">
                  <span className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-[#00ff41]/60 bg-[#00ff41]/10 py-3 text-sm font-extrabold text-[#00ff41]">
                    <Check size={16} /> IN YOUR GALLERY
                  </span>
                  <button onClick={p.onOpenGallery} className="glow-btn flex items-center gap-2 rounded-xl bg-[#00ff41] px-4 py-3 text-sm font-extrabold text-black">
                    <Images size={16} /> VIEW
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => void download()}
                  disabled={busy}
                  className="glow-btn flex w-full items-center justify-center gap-2 rounded-xl bg-[#00ff41] py-3.5 text-sm font-extrabold text-black disabled:opacity-70"
                >
                  {busy ? <Loader2 size={17} className="animate-spin" /> : <Download size={17} />}
                  {busy ? (progress !== null && progress > 0 ? `DOWNLOADING… ${Math.round(progress * 100)}%` : "DOWNLOADING THROUGH YOUR CIRCUIT…") : "DOWNLOAD TO GALLERY"}
                </button>
              )}
              <p className="text-center text-[11px] leading-relaxed text-[#51755c]">
                Downloads go <b className="text-[#7fae8a]">only into your FreeOnion Gallery</b> on this device — auto-sorted into the {ALBUM_LABEL[p.item.kind]}. Nothing is saved to your phone's downloads folder.
              </p>
            </>
          ) : (
            <>
              <div className="flex flex-wrap items-center gap-2 text-xs text-[#7fae8a]">
                {p.item.size !== undefined && <span className="rounded-lg border border-[#12351a] bg-black/40 px-2 py-1 font-mono">{formatBytes(p.item.size)}</span>}
                {p.item.mime && <span className="rounded-lg border border-[#12351a] bg-black/40 px-2 py-1 font-mono">{p.item.mime}</span>}
                {p.item.createdAt && <span className="rounded-lg border border-[#12351a] bg-black/40 px-2 py-1">{new Date(p.item.createdAt).toLocaleString()}</span>}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={exportToDevice} className="flex items-center justify-center gap-2 rounded-xl border border-[#00ff41]/50 py-2.5 text-xs font-bold text-[#00ff41] transition hover:bg-[#00ff41]/10">
                  <FileDown size={14} /> Export to device
                </button>
                <button onClick={() => void remove()} className="flex items-center justify-center gap-2 rounded-xl border border-[#ff5c7a]/50 py-2.5 text-xs font-bold text-[#ff5c7a] transition hover:bg-[#ff5c7a]/10">
                  <Trash2 size={14} /> Delete from gallery
                </button>
              </div>
            </>
          )}

          <div className="flex flex-wrap gap-2">
            {p.item.pageUrl && (
              <button onClick={() => p.onOpen(p.item.pageUrl as string)} className="flex items-center gap-1.5 rounded-full border border-[#12351a] px-3 py-1.5 text-[11px] font-semibold text-[#9dffb0] transition hover:border-[#1d5c2c]">
                <ExternalLink size={11} /> Open source page
              </button>
            )}
            {p.item.linkUrl && (
              <button onClick={() => p.onOpen(p.item.linkUrl as string)} className="flex items-center gap-1.5 rounded-full border border-[#9d00ff]/40 px-3 py-1.5 text-[11px] font-semibold text-[#b26bff] transition hover:bg-[#9d00ff]/10">
                <ExternalLink size={11} /> Open the link behind it
              </button>
            )}
            <button onClick={() => p.onOpen(p.item.url, true)} className="flex items-center gap-1.5 rounded-full border border-[#12351a] px-3 py-1.5 text-[11px] font-semibold text-[#9dffb0] transition hover:border-[#1d5c2c]">
              <ExternalLink size={11} /> Open file in new tab
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function previewToViewerItem(m: MediaPreview): ViewerItem {
  return { url: m.url, kind: m.kind, name: m.name, pageUrl: m.pageUrl, linkUrl: m.linkUrl ?? null };
}
