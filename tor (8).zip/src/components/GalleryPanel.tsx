"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Download, Film, FileImage, HardDrive, Images, Link2, Loader2, Play, Search, Trash2,
} from "lucide-react";
import {
  downloadToGallery, formatBytes, galleryDelete, galleryList,
  type GalleryRecord, type MediaKind,
} from "@/lib/galleryStore";
import { displayHost, normalizeInput, shortOnion } from "@/lib/directory";
import type { ViewerItem } from "./MediaViewer";

type Album = "all" | MediaKind;

const ALBUMS: { id: Album; label: string; icon: React.ReactNode }[] = [
  { id: "all", label: "All media", icon: <Images size={13} /> },
  { id: "image", label: "Images", icon: <FileImage size={13} /> },
  { id: "video", label: "Videos", icon: <Film size={13} /> },
  { id: "gif", label: "GIFs", icon: <Play size={13} /> },
];

interface Props {
  refreshKey: number;
  cc: string;
  device: string;
  onView: (item: ViewerItem) => void;
  onCountChange: (n: number) => void;
  toast: (title: string, body?: string, tone?: "green" | "violet" | "red") => void;
}

function Thumb({ rec, onView, onDelete }: { rec: GalleryRecord; onView: () => void; onDelete: () => void }) {
  const [url, setUrl] = useState("");
  useEffect(() => {
    const u = URL.createObjectURL(rec.blob);
    setUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [rec.blob]);

  return (
    <div className="group relative overflow-hidden rounded-2xl border border-[#12351a] bg-black transition hover:border-[#00ff41]/60 hover:shadow-[0_0_16px_rgba(0,255,65,0.15)]">
      <button onClick={onView} className="block aspect-square w-full">
        {url &&
          (rec.kind === "video" ? (
            <video src={`${url}#t=0.1`} muted playsInline preload="metadata" className="h-full w-full object-cover" />
          ) : (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={url} alt={rec.name} loading="lazy" className="h-full w-full object-cover" />
          ))}
      </button>

      {rec.kind === "video" && (
        <span className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-black/60 text-[#00ff41] shadow-[0_0_16px_rgba(0,255,65,0.4)]">
            <Play size={17} className="ml-0.5 fill-[#00ff41]" />
          </span>
        </span>
      )}
      <span className={`absolute left-1.5 top-1.5 rounded-md px-1.5 py-0.5 font-mono text-[9px] font-extrabold tracking-wide ${rec.kind === "gif" ? "bg-[#9d00ff] text-white" : rec.kind === "video" ? "bg-[#00ff41] text-black" : "bg-black/70 text-[#00ff41]"}`}>
        {rec.kind === "gif" ? "GIF" : rec.kind === "video" ? "VIDEO" : "IMG"}
      </span>
      <button
        onClick={onDelete}
        title="Delete from gallery"
        className="absolute right-1.5 top-1.5 rounded-md bg-black/70 p-1.5 text-[#ff8fa3] opacity-0 transition hover:text-[#ff5c7a] group-hover:opacity-100 max-lg:opacity-80"
      >
        <Trash2 size={12} />
      </button>

      <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent px-2 pb-1.5 pt-6">
        <div className="truncate text-[11px] font-bold text-white">{rec.name}</div>
        <div className="flex items-center justify-between font-mono text-[9px] text-[#9dffb0]">
          <span>{formatBytes(rec.size)}</span>
          <span className="max-w-[60%] truncate text-[#7fae8a]">{shortOnion(displayHost(rec.sourceUrl))}</span>
        </div>
      </div>
    </div>
  );
}

export default function GalleryPanel(p: Props) {
  const [items, setItems] = useState<GalleryRecord[]>([]);
  const [album, setAlbum] = useState<Album>("all");
  const [query, setQuery] = useState("");
  const [link, setLink] = useState("");
  const [adding, setAdding] = useState(false);
  const [usage, setUsage] = useState<string>("");
  const blobUrls = useRef(new Map<string, string>());

  const load = useCallback(async () => {
    const list = await galleryList();
    setItems(list);
    p.onCountChange(list.length);
    try {
      const est = await navigator.storage?.estimate?.();
      if (est?.usage) setUsage(formatBytes(est.usage));
    } catch { /* ignore */ }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [p.refreshKey]);

  useEffect(() => {
    void load();
  }, [load]);

  const counts = useMemo(
    () => ({
      all: items.length,
      image: items.filter((i) => i.kind === "image").length,
      video: items.filter((i) => i.kind === "video").length,
      gif: items.filter((i) => i.kind === "gif").length,
    }),
    [items],
  );

  const visible = useMemo(
    () =>
      items.filter(
        (i) =>
          (album === "all" || i.kind === album) &&
          (i.name + i.sourceUrl).toLowerCase().includes(query.toLowerCase()),
      ),
    [items, album, query],
  );

  const totalSize = useMemo(() => items.reduce((s, i) => s + i.size, 0), [items]);

  const viewRecord = (rec: GalleryRecord) => {
    let u = blobUrls.current.get(rec.id);
    if (!u) {
      u = URL.createObjectURL(rec.blob);
      blobUrls.current.set(rec.id, u);
    }
    p.onView({
      url: rec.sourceUrl, kind: rec.kind, name: rec.name, pageUrl: rec.pageUrl,
      recordId: rec.id, blobUrl: u, size: rec.size, createdAt: rec.createdAt, mime: rec.mime,
    });
  };

  const remove = async (rec: GalleryRecord) => {
    await galleryDelete(rec.id);
    await load();
    p.toast("Removed from Gallery", `“${rec.name}” deleted from this device.`, "violet");
  };

  const addByLink = async (e: React.FormEvent) => {
    e.preventDefault();
    const url = normalizeInput(link);
    if (!url) return;
    setAdding(true);
    try {
      const rec = await downloadToGallery(url, { cc: p.cc, device: p.device });
      setLink("");
      await load();
      setAlbum(rec.kind);
      p.toast("Added to your Gallery", `“${rec.name}” · ${formatBytes(rec.size)}`);
    } catch (err) {
      p.toast("Could not download that link", err instanceof Error ? err.message : "Try a direct image/video/GIF file link.", "red");
    } finally {
      setAdding(false);
    }
  };

  return (
    <div className="flex flex-col gap-3 p-4">
      {/* albums */}
      <div className="grid grid-cols-4 gap-1.5">
        {ALBUMS.map((a) => (
          <button
            key={a.id}
            onClick={() => setAlbum(a.id)}
            className={`flex flex-col items-center gap-1 rounded-xl border px-1 py-2 transition ${
              album === a.id
                ? a.id === "gif"
                  ? "border-[#b26bff] bg-[#9d00ff]/15 text-[#b26bff] shadow-[0_0_12px_rgba(157,0,255,0.3)]"
                  : "border-[#00ff41] bg-[#00ff41]/10 text-[#00ff41] shadow-[0_0_12px_rgba(0,255,65,0.25)]"
                : "border-[#12351a] text-[#7fae8a] hover:border-[#1d5c2c]"
            }`}
          >
            <span className="flex items-center gap-1 text-[11px] font-bold">{a.icon} {a.label}</span>
            <span className="font-mono text-[10px] opacity-80">{counts[a.id]} items</span>
          </button>
        ))}
      </div>

      {/* add by link */}
      <form onSubmit={addByLink} className="flex items-center gap-2 rounded-2xl border border-[#1d5c2c] bg-black/50 p-1.5 focus-within:border-[#00ff41]">
        <Link2 size={15} className="ml-1.5 flex-none text-[#7fae8a]" />
        <input
          value={link}
          onChange={(e) => setLink(e.target.value)}
          placeholder="Paste image / video / GIF link to save here…"
          className="min-w-0 flex-1 bg-transparent font-mono text-xs text-[#eaffef] outline-none placeholder:font-sans placeholder:text-[#51755c]"
          autoCapitalize="off"
          autoCorrect="off"
          spellCheck={false}
        />
        <button type="submit" disabled={adding || !link.trim()} className="flex flex-none items-center gap-1 rounded-xl bg-[#00ff41] px-3 py-2 text-[11px] font-extrabold text-black disabled:opacity-50">
          {adding ? <Loader2 size={12} className="animate-spin" /> : <Download size={12} />} SAVE
        </button>
      </form>

      {/* search + storage */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#7fae8a]" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search your gallery…"
            className="w-full rounded-xl border border-[#12351a] bg-black/50 py-1.5 pl-8 pr-2 text-xs text-[#d8ffe0] outline-none placeholder:text-[#51755c] focus:border-[#00ff41]"
          />
        </div>
        <span className="flex flex-none items-center gap-1 font-mono text-[10px] text-[#51755c]" title="Stored on this device">
          <HardDrive size={11} /> {formatBytes(totalSize)}{usage ? ` / ${usage}` : ""}
        </span>
      </div>

      {/* grid */}
      {visible.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-[#1d5c2c] p-6 text-center">
          <Images className="mx-auto text-[#00ff41]" size={28} />
          <p className="mt-2 text-sm font-semibold text-[#d8ffe0]">
            {items.length === 0 ? "Your gallery is empty" : `No ${album === "all" ? "media" : album + "s"} match`}
          </p>
          <p className="mx-auto mt-1 max-w-[260px] text-xs leading-relaxed text-[#7fae8a]">
            Browse any website, then <b className="text-[#9dffb0]">tap any picture, video or GIF</b> (or hover and hit <b className="text-[#00ff41]">↓ SAVE</b>) and press
            <b className="text-[#9dffb0]"> Download to Gallery</b>. It lands here, auto-sorted into Images, Videos and GIFs albums — only on this device.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-2 min-[420px]:grid-cols-3">
          {visible.map((rec) => (
            <Thumb key={rec.id} rec={rec} onView={() => viewRecord(rec)} onDelete={() => void remove(rec)} />
          ))}
        </div>
      )}

      <p className="text-center text-[10px] leading-relaxed text-[#51755c]">
        Gallery media is stored privately in this app on your device (IndexedDB). Use “Export to device” inside any item if you ever want a copy outside FreeOnion.
      </p>
    </div>
  );
}
