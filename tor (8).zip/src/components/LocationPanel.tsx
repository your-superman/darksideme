"use client";

import { useMemo, useState } from "react";
import { Dices, Fingerprint, Globe2, MapPin, RefreshCw, Search, ShieldCheck, Timer, Zap } from "lucide-react";
import { EXIT_COUNTRIES, type Identity } from "@/lib/exitNodes";
import type { AppSettings } from "./types";

interface Props {
  identity: Identity | null;
  busy: boolean;
  torConnected: boolean;
  settings: AppSettings;
  countdown: number;
  onNewIdentity: (countryCode?: string) => void;
  onSettings: (s: AppSettings) => void;
}

const ROTATE_OPTIONS = [
  { value: 30, label: "Every 30 seconds" },
  { value: 60, label: "Every 1 minute" },
  { value: 300, label: "Every 5 minutes" },
  { value: 600, label: "Every 10 minutes" },
  { value: 1800, label: "Every 30 minutes" },
];

function fmtCountdown(sec: number) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return m > 0 ? `${m}m ${String(s).padStart(2, "0")}s` : `${s}s`;
}

export default function LocationPanel({ identity, busy, torConnected, settings, countdown, onNewIdentity, onSettings }: Props) {
  const [query, setQuery] = useState("");
  const countries = useMemo(
    () =>
      EXIT_COUNTRIES.filter(
        (c) => c.name.toLowerCase().includes(query.toLowerCase()) || c.code.toLowerCase().includes(query.toLowerCase()),
      ),
    [query],
  );

  return (
    <div className="flex flex-col gap-4 p-4">
      {/* Current identity */}
      <section className="neon-border rounded-2xl bg-[#050a06] p-4">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.18em] text-[#7fae8a]">
            <Fingerprint size={14} className="text-[#00ff41]" /> Current identity
          </span>
          <span
            className={`flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[10px] font-mono ${
              torConnected
                ? "border-[#00ff41]/50 text-[#00ff41]"
                : "border-[#b26bff]/50 text-[#b26bff]"
            }`}
          >
            <span className={`h-1.5 w-1.5 rounded-full ${torConnected ? "bg-[#00ff41] pulse-dot" : "bg-[#b26bff]"}`} />
            {torConnected ? "TOR DAEMON LIVE" : "GATEWAY MODE"}
          </span>
        </div>

        {identity ? (
          <>
            <div className="mt-3 font-mono text-[26px] font-extrabold leading-none text-white">
              {identity.exitIp}
            </div>
            <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
              <span className="rounded-md bg-[#9d00ff]/20 px-2 py-1 font-mono font-bold text-[#b26bff]">{identity.countryCode}</span>
              <span className="flex items-center gap-1 text-[#9dffb0]">
                <MapPin size={13} /> {identity.city}, {identity.countryName}
              </span>
              <span className="flex items-center gap-1 text-[#7fae8a]">
                <Zap size={13} /> {identity.latencyMs} ms
              </span>
            </div>
            <div className="mt-3 grid grid-cols-3 gap-1.5 text-center font-mono text-[10px]">
              <div className="rounded-lg border border-[#12351a] bg-black/40 px-1 py-1.5">
                <div className="text-[#7fae8a]">LOCALE</div>
                <div className="text-[#9dffb0]">{identity.locale}</div>
              </div>
              <div className="rounded-lg border border-[#12351a] bg-black/40 px-1 py-1.5">
                <div className="text-[#7fae8a]">TIMEZONE</div>
                <div className="truncate text-[#9dffb0]">{identity.timezone.split("/")[1] || identity.timezone}</div>
              </div>
              <div className="rounded-lg border border-[#12351a] bg-black/40 px-1 py-1.5">
                <div className="text-[#7fae8a]">CIRCUIT</div>
                <div className="text-[#9dffb0]">{identity.circuitId}</div>
              </div>
            </div>

            {/* circuit hops */}
            <div className="mt-3 space-y-1.5">
              {identity.hops.map((hop, i) => (
                <div key={hop.role} className="flex items-center gap-2 rounded-lg border border-[#12351a] bg-black/30 px-2.5 py-1.5 text-[11px]">
                  <span className={`flex h-5 w-5 flex-none items-center justify-center rounded-full font-mono font-bold ${i === 2 ? "bg-[#00ff41] text-black" : "bg-[#12351a] text-[#00ff41]"}`}>
                    {i + 1}
                  </span>
                  <span className="w-12 flex-none font-bold uppercase tracking-wide text-[#7fae8a]">{hop.role}</span>
                  <span className="min-w-0 flex-1 truncate text-[#d8ffe0]">{hop.name}</span>
                  <span className="flex-none rounded bg-[#9d00ff]/15 px-1.5 py-0.5 font-mono text-[10px] font-bold text-[#b26bff]">{hop.countryCode}</span>
                  <span className="hidden flex-none font-mono text-[10px] text-[#7fae8a] sm:block">{hop.ip}</span>
                </div>
              ))}
            </div>
          </>
        ) : (
          <p className="mt-3 text-sm text-[#7fae8a]">Building your first circuit…</p>
        )}

        <div className="mt-4 flex gap-2">
          <button
            onClick={() => onNewIdentity()}
            disabled={busy}
            className="glow-btn flex flex-1 items-center justify-center gap-2 rounded-xl bg-[#00ff41] px-3 py-2.5 text-sm font-extrabold text-black disabled:opacity-60"
          >
            <RefreshCw size={16} className={busy ? "animate-spin" : ""} />
            {busy ? "Rebuilding…" : "NEW IDENTITY"}
          </button>
          <button
            onClick={() => onNewIdentity("RANDOM")}
            disabled={busy}
            className="flex items-center justify-center gap-2 rounded-xl border border-[#9d00ff]/60 bg-[#9d00ff]/10 px-3 py-2.5 text-sm font-bold text-[#b26bff] transition hover:bg-[#9d00ff]/25 disabled:opacity-60"
            title="Random country"
          >
            <Dices size={16} /> Random
          </button>
        </div>
        <p className="mt-2.5 flex items-start gap-1.5 text-[11px] leading-relaxed text-[#7fae8a]">
          <ShieldCheck size={13} className="mt-0.5 flex-none text-[#00ff41]" />
          New Identity burns the old circuit and builds a fresh 3-hop path with a new exit IP, locale and timezone fingerprint.
        </p>
      </section>

      {/* Auto rotate */}
      <section className="rounded-2xl border border-[#12351a] bg-[#050a06] p-4">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.18em] text-[#7fae8a]">
            <Timer size={14} className="text-[#00ff41]" /> Auto-change IP &amp; location
          </span>
          <button
            className="fo-switch"
            data-on={settings.autoRotate}
            aria-label="Toggle auto rotate"
            onClick={() => onSettings({ ...settings, autoRotate: !settings.autoRotate })}
          />
        </div>
        <div className={`mt-3 space-y-3 ${settings.autoRotate ? "" : "pointer-events-none opacity-40"}`}>
          <select
            className="fo-select w-full"
            value={settings.rotateSeconds}
            onChange={(e) => onSettings({ ...settings, rotateSeconds: Number(e.target.value) })}
          >
            {ROTATE_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
          <div className="flex items-center justify-between text-xs">
            <span className="text-[#d8ffe0]">Random country on each rotation</span>
            <button
              className="fo-switch"
              data-on={settings.randomCountry}
              aria-label="Toggle random country"
              onClick={() => onSettings({ ...settings, randomCountry: !settings.randomCountry })}
            />
          </div>
          <div>
            <div className="mb-1 flex justify-between font-mono text-[10px] text-[#7fae8a]">
              <span>NEXT ROTATION</span>
              <span className="text-[#00ff41]">{settings.autoRotate ? fmtCountdown(countdown) : "—"}</span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-[#0a1f10]">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#9d00ff] to-[#00ff41] transition-[width] duration-1000 ease-linear"
                style={{ width: `${settings.autoRotate ? Math.max(2, (countdown / settings.rotateSeconds) * 100) : 0}%` }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Country picker */}
      <section className="rounded-2xl border border-[#12351a] bg-[#050a06] p-4">
        <span className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.18em] text-[#7fae8a]">
          <Globe2 size={14} className="text-[#00ff41]" /> Exit anywhere in the world
        </span>
        <div className="relative mt-3">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#7fae8a]" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search countries…"
            className="w-full rounded-xl border border-[#1d5c2c] bg-black/50 py-2 pl-9 pr-3 text-sm text-[#d8ffe0] outline-none placeholder:text-[#51755c] focus:border-[#00ff41] focus:shadow-[0_0_12px_rgba(0,255,65,0.25)]"
          />
        </div>
        <div className="mt-3 grid grid-cols-2 gap-1.5">
          {countries.map((c) => {
            const active = identity?.countryCode === c.code;
            return (
              <button
                key={c.code}
                onClick={() => onNewIdentity(c.code)}
                disabled={busy}
                className={`group flex items-center gap-2 rounded-xl border px-2.5 py-2 text-left transition disabled:opacity-50 ${
                  active
                    ? "border-[#00ff41] bg-[#00ff41]/10 shadow-[0_0_14px_rgba(0,255,65,0.25)]"
                    : "border-[#12351a] bg-black/30 hover:border-[#1d5c2c] hover:bg-[#00ff41]/5"
                }`}
              >
                <span className={`flex h-7 w-9 flex-none items-center justify-center rounded-md font-mono text-[11px] font-extrabold ${active ? "bg-[#00ff41] text-black" : "bg-[#9d00ff]/20 text-[#b26bff] group-hover:bg-[#9d00ff]/35"}`}>
                  {c.code}
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-xs font-semibold text-[#d8ffe0]">{c.name}</span>
                  <span className="block truncate text-[10px] text-[#7fae8a]">{c.cities[0]} · {c.cities.length} exits</span>
                </span>
                {active && <span className="ml-auto h-2 w-2 flex-none rounded-full bg-[#00ff41] pulse-dot" />}
              </button>
            );
          })}
        </div>
        {countries.length === 0 && <p className="mt-3 text-center text-xs text-[#7fae8a]">No exit country matches “{query}”.</p>}
      </section>
    </div>
  );
}
