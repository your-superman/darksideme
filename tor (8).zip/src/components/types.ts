export interface TabState {
  id: string;
  url: string; // "" means the FreeOnion home / new-tab page
  title: string;
  loading: boolean;
  via: string;
  stack: string[];
  index: number;
  reloadKey: number;
}

export interface BookmarkItem {
  id: string;
  name: string;
  url: string;
  folder: string;
  note: string;
  pinned: boolean;
  createdAt: number;
}

export interface HistoryItem {
  id: string;
  title: string;
  url: string;
  at: number;
  countryCode: string;
}

export type SecurityLevel = "standard" | "safer" | "safest";
export type DeviceMode = "desktop" | "android";

export interface AppSettings {
  security: SecurityLevel;
  autoRotate: boolean;
  rotateSeconds: number;
  randomCountry: boolean;
  deviceMode: DeviceMode;
}

export interface ToastMsg {
  id: number;
  title: string;
  body?: string;
  tone: "green" | "violet" | "red";
}

export type PanelTab = "location" | "saved" | "explore" | "history" | "gallery";

/** A picture / video / GIF the user tapped on a web page. */
export interface MediaPreview {
  url: string;
  kind: "image" | "video" | "gif";
  name?: string;
  pageUrl?: string;
  linkUrl?: string | null;
}

export const DEFAULT_SETTINGS: AppSettings = {
  security: "standard",
  autoRotate: true,
  rotateSeconds: 300,
  randomCountry: true,
  deviceMode: "desktop",
};

export function uid(prefix = "id"): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
