"use client";

import { useMemo, useState } from "react";
import {
  BookmarkPlus, Clock3, Compass, ExternalLink, FolderOpen, Pin, PinOff, Search, SquarePen, Trash2,
} from "lucide-react";
import { DIRECTORY_SITES, displayHost, isOnionUrl, shortOnion } from "@/lib/directory";
import type { BookmarkItem, HistoryItem } from "./types";
import { OnionGlyph } from "./brand";

interface Props {
  tab: "saved" | "explore" | "history";
  bookmarks: BookmarkItem[];
  history: HistoryItem[];
  onOpen: (url: string, newTab?: boolean) => void;
  onSaveSite: (url: string, name: string) => void;
  onEditBookmark: (b: BookmarkItem) => void;
  onDeleteBookmark: (id: string) => void;
  onTogglePin: (b: BookmarkItem) => void;
  onDeleteHistory: (id: string) => void;
  onClearHistory: () => void;
}

function Avatar({ name, url }: { name: string; url: string }) {
  const onion = isOnionUrl(url);
  return (
    <span
      className={`flex h-9 w-9 flex-none items-center justify-center rounded-xl font-mono text-sm font-extrabold ${
        onion ? "bg-[#9d00ff]/20 text-[#b26bff] shadow-[inset_0_0_0_1px_rgba(157,0,255,0.4)]" : "bg-[#00ff41]/12 text-[#00ff41] shadow-[inset_0_0_0_1px_rgba(0,255,65,0.3)]"
      }`}
    >
      {onion ? <OnionGlyph size={18} /> : (name.trim()[0] || "?").toUpperCase()}
    </span>
  );
}

function timeAgo(ts: number) {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return "just now";
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

export default function LibraryPanel(p: Props) {
  const [query, setQuery] = useState("");
  const [folder, setFolder] = useState<string>("All");
  const [category, setCategory] = useState<string>("All");

  const folders = useMemo(() => ["All", ...Array.from(new Set(p.bookmarks.map((b) => b.folder)))], [p.bookmarks]);
  const categories = useMemo(() => ["All", ...Array.from(new Set(DIRECTORY_SITES.map((s) => s.category)))], []);

  const saved = useMemo(
    () =>
      p.bookmarks
        .filter((b) => (folder === "All" || b.folder === folder) && (b.name + b.url).toLowerCase().includes(query.toLowerCase()))
        .sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.createdAt - a.createdAt),
    [p.bookmarks, folder, query],
  );

  const sites = useMemo(
    () =>
      DIRECTORY_SITES.filter(
        (s) => (category === "All" || s.category === category) && (s.name + s.url + s.description).toLowerCase().includes(query.toLowerCase()),
      ),
    [category, query],
  );

  const hist = useMemo(
    () => p.history.filter((h) => (h.title + h.url).toLowerCase().includes(query.toLowerCase())),
    [p.history, query],
  );

  const searchBox = (
    <div className="relative">
      <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#7fae8a]" />
      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder={p.tab === "saved" ? "Search saved sites…" : p.tab === "explore" ? "Search the onion directory…" : "Search history…"}
        className="w-full rounded-xl border border-[#1d5c2c] bg-black/50 py-2 pl-9 pr-3 text-sm text-[#d8ffe0] outline-none placeholder:text-[#51755c] focus:border-[#00ff41] focus:shadow-[0_0_12px_rgba(0,255,65,0.25)]"
      />
    </div>
  );

  if (p.tab === "saved") {
    return (
      <div className="flex flex-col gap-3 p-4">
        {searchBox}
        <div className="flex flex-wrap gap-1.5">
          {folders.map((f) => (
            <button
              key={f}
              onClick={() => setFolder(f)}
              className={`flex items-center gap-1 rounded-full border px-2.5 py-1 text-[11px] font-semibold transition ${
                folder === f ? "border-[#00ff41] bg-[#00ff41]/15 text-[#00ff41]" : "border-[#12351a] text-[#7fae8a] hover:border-[#1d5c2c]"
              }`}
            >
              <FolderOpen size={11} /> {f}
            </button>
          ))}
        </div>

        {saved.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-[#1d5c2c] p-6 text-center">
            <BookmarkPlus className="mx-auto text-[#00ff41]" size={26} />
            <p className="mt-2 text-sm font-semibold text-[#d8ffe0]">No saved sites yet</p>
            <p className="mx-auto mt-1 max-w-[240px] text-xs leading-relaxed text-[#7fae8a]">
              Open any website, tap the star in the address bar and save it under your own name. Stored on this device, free forever.
            </p>
          </div>
        ) : (
          saved.map((b) => (
            <div key={b.id} className="group flex items-center gap-3 rounded-2xl border border-[#12351a] bg-[#050a06] p-3 transition hover:border-[#1d5c2c]">
              <Avatar name={b.name} url={b.url} />
              <button className="min-w-0 flex-1 text-left" onClick={() => p.onOpen(b.url)}>
                <span className="flex items-center gap-1.5 truncate text-sm font-bold text-[#eaffef]">
                  {b.name}
                  {b.pinned && <Pin size={11} className="flex-none text-[#00ff41]" />}
                </span>
                <span className="block truncate font-mono text-[11px] text-[#7fae8a]">{shortOnion(displayHost(b.url))}</span>
                {b.note && <span className="block truncate text-[11px] text-[#51755c]">{b.note}</span>}
              </button>
              <div className="flex flex-none flex-col gap-1">
                <div className="flex gap-1">
                  <button onClick={() => p.onOpen(b.url, true)} title="Open in new tab" className="rounded-lg border border-[#12351a] p-1.5 text-[#7fae8a] transition hover:border-[#00ff41] hover:text-[#00ff41]">
                    <ExternalLink size={13} />
                  </button>
                  <button onClick={() => p.onTogglePin(b)} title={b.pinned ? "Unpin from home" : "Pin to home speed-dial"} className="rounded-lg border border-[#12351a] p-1.5 text-[#7fae8a] transition hover:border-[#00ff41] hover:text-[#00ff41]">
                    {b.pinned ? <PinOff size={13} /> : <Pin size={13} />}
                  </button>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => p.onEditBookmark(b)} title="Rename / edit" className="rounded-lg border border-[#12351a] p-1.5 text-[#7fae8a] transition hover:border-[#b26bff] hover:text-[#b26bff]">
                    <SquarePen size={13} />
                  </button>
                  <button onClick={() => p.onDeleteBookmark(b.id)} title="Delete" className="rounded-lg border border-[#12351a] p-1.5 text-[#7fae8a] transition hover:border-[#ff5c7a] hover:text-[#ff5c7a]">
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    );
  }

  if (p.tab === "explore") {
    return (
      <div className="flex flex-col gap-3 p-4">
        {searchBox}
        <div className="flex flex-wrap gap-1.5">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={`rounded-full border px-2.5 py-1 text-[11px] font-semibold transition ${
                category === c ? "border-[#b26bff] bg-[#9d00ff]/15 text-[#b26bff]" : "border-[#12351a] text-[#7fae8a] hover:border-[#1d5c2c]"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
        <p className="flex items-start gap-1.5 text-[11px] leading-relaxed text-[#7fae8a]">
          <Compass size={13} className="mt-0.5 flex-none text-[#00ff41]" />
          Verified, well-known onion services. Always double-check onion addresses you find elsewhere — phishing clones are everywhere.
        </p>
        {sites.map((s) => (
          <div key={s.url} className="rounded-2xl border border-[#12351a] bg-[#050a06] p-3 transition hover:border-[#1d5c2c]">
            <div className="flex items-center gap-3">
              <Avatar name={s.name} url={s.url} />
              <button className="min-w-0 flex-1 text-left" onClick={() => p.onOpen(s.url)}>
                <span className="block truncate text-sm font-bold text-[#eaffef]">{s.name}</span>
                <span className="block truncate font-mono text-[11px] text-[#b26bff]">{shortOnion(displayHost(s.url))}</span>
              </button>
              <span className="flex-none rounded-full border border-[#1d5c2c] px-2 py-0.5 text-[10px] font-bold text-[#00ff41]">{s.category}</span>
            </div>
            <p className="mt-2 text-xs leading-relaxed text-[#7fae8a]">{s.description}</p>
            <div className="mt-2.5 flex gap-2">
              <button onClick={() => p.onOpen(s.url)} className="flex-1 rounded-lg bg-[#00ff41]/12 py-1.5 text-xs font-bold text-[#00ff41] transition hover:bg-[#00ff41]/25">
                Open
              </button>
              <button onClick={() => p.onOpen(s.url, true)} className="flex-1 rounded-lg border border-[#12351a] py-1.5 text-xs font-semibold text-[#9dffb0] transition hover:border-[#1d5c2c]">
                New tab
              </button>
              <button onClick={() => p.onSaveSite(s.url, s.name)} className="flex items-center gap-1 rounded-lg border border-[#9d00ff]/40 px-2.5 py-1.5 text-xs font-semibold text-[#b26bff] transition hover:bg-[#9d00ff]/15">
                <BookmarkPlus size={13} /> Save
              </button>
            </div>
          </div>
        ))}
        {sites.length === 0 && <p className="text-center text-xs text-[#7fae8a]">Nothing matches your search.</p>}
      </div>
    );
  }

  // history
  return (
    <div className="flex flex-col gap-3 p-4">
      {searchBox}
      {p.history.length > 0 && (
        <button onClick={p.onClearHistory} className="self-end text-[11px] font-bold text-[#ff5c7a] hover:underline">
          BURN ALL HISTORY
        </button>
      )}
      {hist.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-[#1d5c2c] p-6 text-center">
          <Clock3 className="mx-auto text-[#00ff41]" size={26} />
          <p className="mt-2 text-sm font-semibold text-[#d8ffe0]">No history stored</p>
          <p className="mx-auto mt-1 max-w-[240px] text-xs leading-relaxed text-[#7fae8a]">
            Sites you visit appear here, stored only in this browser on your device. Burn it anytime.
          </p>
        </div>
      ) : (
        hist.map((h) => (
          <div key={h.id} className="flex items-center gap-3 rounded-2xl border border-[#12351a] bg-[#050a06] p-3 transition hover:border-[#1d5c2c]">
            <Avatar name={h.title || displayHost(h.url)} url={h.url} />
            <button className="min-w-0 flex-1 text-left" onClick={() => p.onOpen(h.url)}>
              <span className="block truncate text-sm font-semibold text-[#eaffef]">{h.title || shortOnion(displayHost(h.url))}</span>
              <span className="block truncate font-mono text-[11px] text-[#7fae8a]">{shortOnion(displayHost(h.url))}</span>
              <span className="mt-0.5 flex items-center gap-2 text-[10px] text-[#51755c]">
                {timeAgo(h.at)}
                {h.countryCode && <span className="rounded bg-[#9d00ff]/15 px-1 py-px font-mono font-bold text-[#b26bff]">via {h.countryCode}</span>}
              </span>
            </button>
            <button onClick={() => p.onSaveSite(h.url, h.title || displayHost(h.url))} title="Save by name" className="rounded-lg border border-[#12351a] p-1.5 text-[#7fae8a] transition hover:border-[#00ff41] hover:text-[#00ff41]">
              <BookmarkPlus size={13} />
            </button>
            <button onClick={() => p.onDeleteHistory(h.id)} title="Delete" className="rounded-lg border border-[#12351a] p-1.5 text-[#7fae8a] transition hover:border-[#ff5c7a] hover:text-[#ff5c7a]">
              <Trash2 size={13} />
            </button>
          </div>
        ))
      )}
    </div>
  );
}
