"use client";

import { useState } from "react";
import Image from "next/image";
import {
  ArrowRight, Check, ClipboardPaste, Copy, Download, Globe2, Images as ImagesIcon, Layers3, MapPin,
  MonitorSmartphone, MousePointerClick, RefreshCw, ShieldCheck, Smartphone,
} from "lucide-react";
import type { Identity } from "@/lib/exitNodes";
import { DIRECTORY_SITES, displayHost, isOnionUrl, shortOnion } from "@/lib/directory";
import type { BookmarkItem } from "./types";
import { LogoMark, OnionGlyph } from "./brand";

interface Props {
  identity: Identity | null;
  busy: boolean;
  bookmarks: BookmarkItem[];
  origin: string;
  isInstalled: boolean;
  onOpenRaw: (input: string) => void;
  onOpen: (url: string, newTab?: boolean) => void;
  onNewIdentity: () => void;
  onOpenPanel: (tab: "location" | "saved" | "explore" | "history" | "gallery") => void;
  onInstall: () => void;
  toast: (title: string, body?: string, tone?: "green" | "violet" | "red") => void;
}

export default function HomeScreen(p: Props) {
  const [input, setInput] = useState("");
  const [copied, setCopied] = useState(false);
  const pinned = p.bookmarks.filter((b) => b.pinned);
  const dialSites = pinned.length > 0 ? pinned : DIRECTORY_SITES.slice(0, 8).map((s) => ({ id: s.url, name: s.name, url: s.url, folder: "", note: s.category, pinned: false, createdAt: 0 }));

  const pasteFromClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setInput(text.trim());
        p.toast("Link pasted", "Hit GO to open it through your circuit.");
      } else p.toast("Clipboard is empty", "Copy an .onion link first.", "violet");
    } catch {
      p.toast("Clipboard blocked", "Long-press the box and paste manually.", "red");
    }
  };

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(p.origin);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      p.toast("Live link copied", "Open it on any phone or PC to install FreeOnion free.");
    } catch {
      p.toast("Copy failed", p.origin, "red");
    }
  };

  const hops = p.identity?.hops ?? [];

  return (
    <div className="grid-bg relative h-full overflow-y-auto">
      {/* hero */}
      <div className="relative overflow-hidden">
        <Image src="/images/circuit-hero.jpg" alt="" fill className="object-cover opacity-45" priority />
        <div className="absolute inset-0 bg-gradient-to-b from-black/55 via-[#020403]/72 to-[#020403]" />
        <div className="relative mx-auto max-w-3xl px-4 pb-10 pt-10 text-center sm:pt-14">
          <div className="rise flex justify-center">
            <LogoMark size={88} />
          </div>
          <h1 className="rise mt-4 font-mono text-4xl font-extrabold tracking-tight sm:text-5xl" style={{ animationDelay: "60ms" }}>
            <span className="neon-text flicker">FREE</span>
            <span className="violet-text">ONION</span>
          </h1>
          <p className="rise mx-auto mt-3 max-w-xl text-sm leading-relaxed text-[#9dffb0] sm:text-base" style={{ animationDelay: "120ms" }}>
            Paste any <span className="font-mono font-bold text-[#b26bff]">.onion</span> link and view it instantly — in unlimited tabs,
            from any country on Earth, with a fresh IP whenever you want. Free forever. Your data never leaves this device.
          </p>

          <form
            className="rise mx-auto mt-6 flex max-w-xl items-center gap-2 rounded-2xl border border-[#00ff41]/45 bg-black/70 p-2 shadow-[0_0_28px_rgba(0,255,65,0.22)] backdrop-blur"
            style={{ animationDelay: "180ms" }}
            onSubmit={(e) => {
              e.preventDefault();
              if (input.trim()) p.onOpenRaw(input);
            }}
          >
            <OnionGlyph size={20} className="ml-1.5 flex-none" />
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Paste an .onion address or any website link…"
              className="min-w-0 flex-1 bg-transparent font-mono text-sm text-[#eaffef] outline-none placeholder:text-[#51755c]"
              autoCapitalize="off"
              autoCorrect="off"
              spellCheck={false}
            />
            <button type="button" onClick={pasteFromClipboard} title="Paste from clipboard" className="flex-none rounded-xl border border-[#1d5c2c] p-2.5 text-[#9dffb0] transition hover:border-[#00ff41] hover:text-[#00ff41]">
              <ClipboardPaste size={16} />
            </button>
            <button type="submit" className="glow-btn flex flex-none items-center gap-1.5 rounded-xl bg-[#00ff41] px-4 py-2.5 text-sm font-extrabold text-black">
              GO <ArrowRight size={15} />
            </button>
          </form>

          <div className="rise mt-4 flex flex-wrap items-center justify-center gap-2" style={{ animationDelay: "240ms" }}>
            <button onClick={p.onNewIdentity} disabled={p.busy} className="flex items-center gap-1.5 rounded-full border border-[#00ff41]/50 bg-[#00ff41]/10 px-3.5 py-1.5 text-xs font-bold text-[#00ff41] transition hover:bg-[#00ff41]/20 disabled:opacity-60">
              <RefreshCw size={13} className={p.busy ? "animate-spin" : ""} /> New identity &amp; IP
            </button>
            <button onClick={() => p.onOpenPanel("location")} className="flex items-center gap-1.5 rounded-full border border-[#9d00ff]/50 bg-[#9d00ff]/10 px-3.5 py-1.5 text-xs font-bold text-[#b26bff] transition hover:bg-[#9d00ff]/20">
              <Globe2 size={13} /> Change location
              {p.identity && <span className="font-mono text-[10px] opacity-80">· {p.identity.city}, {p.identity.countryCode}</span>}
            </button>
            <button onClick={() => p.onOpenPanel("explore")} className="flex items-center gap-1.5 rounded-full border border-[#1d5c2c] bg-black/50 px-3.5 py-1.5 text-xs font-bold text-[#9dffb0] transition hover:border-[#00ff41]">
              <MousePointerClick size={13} /> Onion directory
            </button>
            <button onClick={() => p.onOpenPanel("gallery")} className="flex items-center gap-1.5 rounded-full border border-[#9d00ff]/50 bg-[#9d00ff]/10 px-3.5 py-1.5 text-xs font-bold text-[#b26bff] transition hover:bg-[#9d00ff]/20">
              <ImagesIcon size={13} /> My gallery
            </button>
            {!p.isInstalled && (
              <button onClick={p.onInstall} className="glow-btn flex items-center gap-1.5 rounded-full bg-[#9d00ff] px-3.5 py-1.5 text-xs font-extrabold text-white">
                <Download size={13} /> Install free app
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-5xl space-y-6 px-4 pb-14">
        {/* circuit visual */}
        <section className="neon-border relative overflow-hidden rounded-3xl bg-[#050a06]/90 p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.2em] text-[#7fae8a]">
              <Layers3 size={15} className="text-[#00ff41]" /> Your live onion circuit
            </h2>
            {p.identity && (
              <span className="font-mono text-[11px] text-[#7fae8a]">
                {p.identity.circuitId} · exit <span className="font-bold text-[#00ff41]">{p.identity.exitIp}</span> · {p.identity.latencyMs} ms
              </span>
            )}
          </div>

          <div className="relative mt-5">
            <svg className="absolute left-0 top-6 hidden h-2 w-full sm:block" preserveAspectRatio="none" viewBox="0 0 100 2">
              <line x1="4" y1="1" x2="96" y2="1" stroke="#00ff41" strokeWidth="0.7" className="circuit-line" opacity="0.75" />
            </svg>
            <div className="relative grid grid-cols-5 gap-2 text-center">
              <CircuitNode label="You" sub="this device" code="YOU" tone="white" />
              {hops.map((h) => (
                <CircuitNode key={h.role} label={h.role} sub={`${h.city}`} code={h.countryCode} tone={h.role === "Exit" ? "green" : "violet"} />
              ))}
              {hops.length === 0 && (
                <>
                  <CircuitNode label="Guard" sub="building…" code="··" tone="violet" />
                  <CircuitNode label="Middle" sub="building…" code="··" tone="violet" />
                  <CircuitNode label="Exit" sub="building…" code="··" tone="green" />
                </>
              )}
              <CircuitNode label="Website" sub=".onion / web" code="WWW" tone="white" />
            </div>
          </div>
          <p className="mt-4 text-center text-[11px] leading-relaxed text-[#7fae8a]">
            Traffic is wrapped in 3 layers of encryption — like an onion. Each relay only knows the hop before and after it.
            The website only ever sees your <span className="font-semibold text-[#00ff41]">exit IP in {p.identity ? p.identity.countryName : "another country"}</span>.
          </p>
        </section>

        {/* speed dial */}
        <section>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-[#7fae8a]">
              {pinned.length > 0 ? "Your pinned sites" : "Popular onion services"}
            </h2>
            <button onClick={() => p.onOpenPanel(pinned.length > 0 ? "saved" : "explore")} className="text-[11px] font-bold text-[#00ff41] hover:underline">
              VIEW ALL
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
            {dialSites.map((s) => (
              <button
                key={s.id}
                onClick={() => p.onOpen(s.url)}
                className="group rounded-2xl border border-[#12351a] bg-[#050a06] p-3.5 text-left transition hover:border-[#00ff41]/60 hover:shadow-[0_0_18px_rgba(0,255,65,0.15)]"
              >
                <span className={`flex h-10 w-10 items-center justify-center rounded-xl font-mono text-base font-extrabold ${isOnionUrl(s.url) ? "bg-[#9d00ff]/20" : "bg-[#00ff41]/12 text-[#00ff41]"}`}>
                  {isOnionUrl(s.url) ? <OnionGlyph size={22} /> : (s.name[0] || "?").toUpperCase()}
                </span>
                <span className="mt-2.5 block truncate text-sm font-bold text-[#eaffef] group-hover:text-[#00ff41]">{s.name}</span>
                <span className="block truncate font-mono text-[10px] text-[#7fae8a]">{shortOnion(displayHost(s.url))}</span>
              </button>
            ))}
          </div>
        </section>

        {/* install card */}
        <section className="relative overflow-hidden rounded-3xl border border-[#9d00ff]/45 bg-gradient-to-br from-[#150826] via-[#050a06] to-black p-5 shadow-[0_0_34px_rgba(157,0,255,0.18)]">
          <div className="flex flex-col items-start gap-4 sm:flex-row sm:items-center">
            <LogoMark size={64} className="flex-none" />
            <div className="min-w-0 flex-1">
              <h2 className="text-lg font-extrabold text-white">
                Install <span className="neon-text">FreeOnion</span> — your one live link
              </h2>
              <p className="mt-1 text-sm leading-relaxed text-[#9dffb0]">
                This address <em>is</em> the app. Open it on any phone or computer and tap install — no app store, no account, no cost.
                It runs offline from local storage with your tabs &amp; saved sites intact.
              </p>
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <code className="max-w-full truncate rounded-xl border border-[#1d5c2c] bg-black/60 px-3 py-2 font-mono text-xs text-[#00ff41]">{p.origin || "https://your-freeonion-link"}</code>
                <button onClick={copyLink} className="flex items-center gap-1.5 rounded-xl border border-[#00ff41]/50 px-3 py-2 text-xs font-bold text-[#00ff41] transition hover:bg-[#00ff41]/10">
                  {copied ? <Check size={13} /> : <Copy size={13} />} {copied ? "Copied" : "Copy link"}
                </button>
                {!p.isInstalled ? (
                  <button onClick={p.onInstall} className="glow-btn flex items-center gap-1.5 rounded-xl bg-[#00ff41] px-4 py-2 text-xs font-extrabold text-black">
                    <Smartphone size={14} /> INSTALL APP — FREE
                  </button>
                ) : (
                  <span className="flex items-center gap-1.5 rounded-xl border border-[#00ff41]/50 px-3 py-2 text-xs font-bold text-[#00ff41]">
                    <Check size={13} /> Installed on this device
                  </span>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* how it works */}
        <section className="grid gap-2.5 sm:grid-cols-3">
          <HowCard icon={<ClipboardPaste size={18} />} title="1 · Paste any link" body="Drop a full 56-character .onion address (or any normal website) into the bar — no Tor Browser download needed." />
          <HowCard icon={<MapPin size={18} />} title="2 · Pick your country" body="Exit from 24 countries or let FreeOnion auto-rotate your IP & location on a timer. One tap = brand-new identity." />
          <HowCard icon={<ShieldCheck size={18} />} title="3 · Browse in tabs" body="Open unlimited tabs, save sites under your own names, pin favourites to this screen. Everything lives in local storage." />
        </section>

        <p className="flex items-center justify-center gap-2 pt-1 text-center text-[11px] text-[#51755c]">
          <MonitorSmartphone size={13} />
          FreeOnion routes through Tor when a local Tor daemon is present, otherwise through public onion gateways.
          For high-risk use, run the official Tor Browser. Stay legal, stay safe.
        </p>
      </div>
    </div>
  );
}

function CircuitNode({ label, sub, code, tone }: { label: string; sub: string; code: string; tone: "green" | "violet" | "white" }) {
  const styles =
    tone === "green"
      ? "border-[#00ff41] bg-[#00ff41]/15 text-[#00ff41] shadow-[0_0_16px_rgba(0,255,65,0.35)]"
      : tone === "violet"
        ? "border-[#9d00ff]/60 bg-[#9d00ff]/12 text-[#b26bff]"
        : "border-[#1d5c2c] bg-black/60 text-white";
  return (
    <div className="flex flex-col items-center">
      <div className={`flex h-12 w-12 items-center justify-center rounded-2xl border font-mono text-[11px] font-extrabold ${styles}`}>{code}</div>
      <div className="mt-2 text-xs font-bold text-[#eaffef]">{label}</div>
      <div className="max-w-full truncate text-[10px] text-[#7fae8a]">{sub}</div>
    </div>
  );
}

function HowCard({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return (
    <div className="rounded-2xl border border-[#12351a] bg-[#050a06] p-4">
      <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#00ff41]/12 text-[#00ff41]">{icon}</span>
      <h3 className="mt-2.5 text-sm font-bold text-[#eaffef]">{title}</h3>
      <p className="mt-1 text-xs leading-relaxed text-[#7fae8a]">{body}</p>
    </div>
  );
}
