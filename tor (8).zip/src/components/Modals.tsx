"use client";

import { useEffect, useMemo, useState } from "react";
import {
  BookmarkPlus, Check, Copy, Download, Eraser, MoreVertical, Share, ShieldAlert,
  ShieldCheck, ShieldHalf, Smartphone, X,
} from "lucide-react";
import type { AppSettings, BookmarkItem, SecurityLevel } from "./types";
import { LogoMark } from "./brand";

function Shell({ children, onClose, wide = false }: { children: React.ReactNode; onClose: () => void; wide?: boolean }) {
  useEffect(() => {
    const fn = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-[90] flex items-end justify-center bg-black/75 backdrop-blur-sm sm:items-center" onClick={onClose}>
      <div
        className={`rise max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl border border-[#1d5c2c] bg-[#040805] shadow-[0_0_50px_rgba(0,255,65,0.18)] sm:rounded-3xl ${wide ? "sm:max-w-lg" : "sm:max-w-md"}`}
        onClick={(e) => e.stopPropagation()}
      >
        {children}
      </div>
    </div>
  );
}

const inputCls =
  "w-full rounded-xl border border-[#1d5c2c] bg-black/60 px-3 py-2.5 text-sm text-[#eaffef] outline-none placeholder:text-[#51755c] focus:border-[#00ff41] focus:shadow-[0_0_12px_rgba(0,255,65,0.25)]";
const labelCls = "mb-1.5 block text-[11px] font-bold uppercase tracking-[0.16em] text-[#7fae8a]";

/* ------------------------------- Save bookmark ------------------------------- */

export interface SaveDraft {
  id?: string;
  name: string;
  url: string;
  folder: string;
  note: string;
  pinned: boolean;
}

export function SaveBookmarkModal({
  draft, folders, onClose, onSave,
}: {
  draft: SaveDraft;
  folders: string[];
  onClose: () => void;
  onSave: (d: SaveDraft) => void;
}) {
  const [name, setName] = useState(draft.name);
  const [url, setUrl] = useState(draft.url);
  const [folder, setFolder] = useState(draft.folder || "Saved");
  const [customFolder, setCustomFolder] = useState("");
  const [note, setNote] = useState(draft.note);
  const [pinned, setPinned] = useState(draft.pinned);
  const isEdit = Boolean(draft.id);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalFolder = folder === "__new" ? customFolder.trim() || "Saved" : folder;
    onSave({ id: draft.id, name: name.trim() || url, url: url.trim(), folder: finalFolder, note: note.trim(), pinned });
  };

  return (
    <Shell onClose={onClose}>
      <form onSubmit={submit} className="p-5">
        <div className="flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-base font-extrabold text-white">
            <BookmarkPlus className="text-[#00ff41]" size={19} />
            {isEdit ? "Edit saved site" : "Save this website"}
          </h2>
          <button type="button" onClick={onClose} className="rounded-lg border border-[#12351a] p-1.5 text-[#7fae8a] hover:text-white">
            <X size={15} />
          </button>
        </div>

        <div className="mt-4 space-y-3.5">
          <div>
            <label className={labelCls}>Save it by a name you remember</label>
            <input autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. My secret forum" className={inputCls} />
          </div>
          <div>
            <label className={labelCls}>Website address</label>
            <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="http://example.onion/…" className={`${inputCls} font-mono text-xs`} autoCapitalize="off" autoCorrect="off" spellCheck={false} />
          </div>
          <div>
            <label className={labelCls}>Folder</label>
            <select value={folder} onChange={(e) => setFolder(e.target.value)} className="fo-select w-full !py-2.5">
              {Array.from(new Set(["Saved", ...folders])).map((f) => (
                <option key={f} value={f}>{f}</option>
              ))}
              <option value="__new">+ New folder…</option>
            </select>
            {folder === "__new" && (
              <input value={customFolder} onChange={(e) => setCustomFolder(e.target.value)} placeholder="New folder name" className={`${inputCls} mt-2`} />
            )}
          </div>
          <div>
            <label className={labelCls}>Note (optional)</label>
            <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Why did you save this?" className={inputCls} />
          </div>
          <div className="flex items-center justify-between rounded-xl border border-[#12351a] bg-black/40 px-3 py-2.5">
            <span className="text-sm text-[#d8ffe0]">Pin to home speed-dial</span>
            <button type="button" className="fo-switch" data-on={pinned} aria-label="Toggle pin" onClick={() => setPinned(!pinned)} />
          </div>
        </div>

        <button type="submit" className="glow-btn mt-5 w-full rounded-xl bg-[#00ff41] py-3 text-sm font-extrabold text-black">
          {isEdit ? "SAVE CHANGES" : "SAVE TO THIS DEVICE — FREE"}
        </button>
        <p className="mt-2.5 text-center text-[11px] text-[#51755c]">Stored in local storage on your device and synced to your FreeOnion vault.</p>
      </form>
    </Shell>
  );
}

/* ------------------------------- Install PWA ------------------------------- */

export function InstallModal({
  origin, canPrompt, onPromptInstall, onClose,
}: {
  origin: string;
  canPrompt: boolean;
  onPromptInstall: () => void;
  onClose: () => void;
}) {
  const [copied, setCopied] = useState(false);
  const platform = useMemo(() => {
    if (typeof navigator === "undefined") return "other";
    const ua = navigator.userAgent;
    if (/iphone|ipad|ipod/i.test(ua)) return "ios";
    if (/android/i.test(ua)) return "android";
    return "desktop";
  }, []);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(origin);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* ignore */ }
  };

  return (
    <Shell onClose={onClose} wide>
      <div className="p-5">
        <div className="flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-base font-extrabold text-white">
            <Smartphone className="text-[#00ff41]" size={19} /> Install FreeOnion app
          </h2>
          <button onClick={onClose} className="rounded-lg border border-[#12351a] p-1.5 text-[#7fae8a] hover:text-white">
            <X size={15} />
          </button>
        </div>

        <div className="mt-4 flex items-center gap-4 rounded-2xl border border-[#9d00ff]/40 bg-gradient-to-br from-[#150826] to-black p-4">
          <LogoMark size={72} className="flex-none" />
          <div className="min-w-0">
            <div className="font-mono text-lg font-extrabold"><span className="neon-text">FREE</span><span className="violet-text">ONION</span></div>
            <p className="mt-0.5 text-xs leading-relaxed text-[#9dffb0]">Real installable app (PWA) — full-screen, offline shell, home-screen icon. No store, no account, 100% free.</p>
          </div>
        </div>

        <label className={`${labelCls} mt-4`}>Your one live link — works on every device</label>
        <div className="flex items-center gap-2">
          <code className="min-w-0 flex-1 truncate rounded-xl border border-[#1d5c2c] bg-black/60 px-3 py-2.5 font-mono text-xs text-[#00ff41]">{origin}</code>
          <button onClick={copy} className="flex flex-none items-center gap-1.5 rounded-xl border border-[#00ff41]/50 px-3 py-2.5 text-xs font-bold text-[#00ff41] hover:bg-[#00ff41]/10">
            {copied ? <Check size={13} /> : <Copy size={13} />} {copied ? "Copied" : "Copy"}
          </button>
        </div>

        {canPrompt && (
          <button onClick={onPromptInstall} className="glow-btn mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-[#00ff41] py-3 text-sm font-extrabold text-black">
            <Download size={16} /> INSTALL NOW — ONE TAP
          </button>
        )}

        <div className="mt-4 space-y-2.5 text-sm">
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#7fae8a]">Manual install steps</p>

          <div className={`rounded-xl border p-3 ${platform === "android" ? "border-[#00ff41]/60 bg-[#00ff41]/5" : "border-[#12351a]"}`}>
            <p className="flex items-center gap-2 font-bold text-[#eaffef]"><MoreVertical size={15} className="text-[#00ff41]" /> Android (Chrome)</p>
            <ol className="ml-5 mt-1 list-decimal space-y-0.5 text-xs leading-relaxed text-[#9dffb0]">
              <li>Open the live link above in Chrome.</li>
              <li>Tap the ⋮ menu (top-right).</li>
              <li>Tap <b>“Install app”</b> / <b>“Add to Home screen”</b> → Install.</li>
            </ol>
          </div>

          <div className={`rounded-xl border p-3 ${platform === "ios" ? "border-[#00ff41]/60 bg-[#00ff41]/5" : "border-[#12351a]"}`}>
            <p className="flex items-center gap-2 font-bold text-[#eaffef]"><Share size={15} className="text-[#00ff41]" /> iPhone / iPad (Safari)</p>
            <ol className="ml-5 mt-1 list-decimal space-y-0.5 text-xs leading-relaxed text-[#9dffb0]">
              <li>Open the live link above in Safari.</li>
              <li>Tap the Share button.</li>
              <li>Tap <b>“Add to Home Screen”</b> → Add.</li>
            </ol>
          </div>

          <div className={`rounded-xl border p-3 ${platform === "desktop" ? "border-[#00ff41]/60 bg-[#00ff41]/5" : "border-[#12351a]"}`}>
            <p className="flex items-center gap-2 font-bold text-[#eaffef]"><Download size={15} className="text-[#00ff41]" /> Windows / Mac (Chrome or Edge)</p>
            <ol className="ml-5 mt-1 list-decimal space-y-0.5 text-xs leading-relaxed text-[#9dffb0]">
              <li>Open the live link above.</li>
              <li>Click the install icon at the right of the address bar.</li>
              <li>Click <b>Install</b> — FreeOnion opens as its own app window.</li>
            </ol>
          </div>
        </div>
      </div>
    </Shell>
  );
}

/* ------------------------------- Settings ------------------------------- */

const SECURITY_OPTIONS: { value: SecurityLevel; icon: React.ReactNode; title: string; body: string }[] = [
  { value: "standard", icon: <ShieldCheck size={17} />, title: "Standard", body: "All website features enabled. Best compatibility with onion sites." },
  { value: "safer", icon: <ShieldHalf size={17} />, title: "Safer", body: "Pages run in an isolated sandbox with no access to this app's storage." },
  { value: "safest", icon: <ShieldAlert size={17} />, title: "Safest", body: "JavaScript disabled inside pages. Sites are read-only; some features break." },
];

export function SettingsModal({
  settings, stats, onSettings, onClearAll, onClose,
}: {
  settings: AppSettings;
  stats: { bookmarks: number; history: number; tabs: number; gallery: number };
  onSettings: (s: AppSettings) => void;
  onClearAll: () => void;
  onClose: () => void;
}) {
  const [confirming, setConfirming] = useState(false);
  return (
    <Shell onClose={onClose}>
      <div className="p-5">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-extrabold text-white">Settings &amp; privacy</h2>
          <button onClick={onClose} className="rounded-lg border border-[#12351a] p-1.5 text-[#7fae8a] hover:text-white">
            <X size={15} />
          </button>
        </div>

        <label className={`${labelCls} mt-4`}>Security level (like Tor Browser)</label>
        <div className="space-y-2">
          {SECURITY_OPTIONS.map((o) => (
            <button
              key={o.value}
              onClick={() => onSettings({ ...settings, security: o.value })}
              className={`flex w-full items-start gap-3 rounded-xl border p-3 text-left transition ${
                settings.security === o.value ? "border-[#00ff41] bg-[#00ff41]/8 shadow-[0_0_14px_rgba(0,255,65,0.18)]" : "border-[#12351a] hover:border-[#1d5c2c]"
              }`}
            >
              <span className={settings.security === o.value ? "text-[#00ff41]" : "text-[#7fae8a]"}>{o.icon}</span>
              <span>
                <span className="block text-sm font-bold text-[#eaffef]">{o.title}</span>
                <span className="block text-xs leading-relaxed text-[#7fae8a]">{o.body}</span>
              </span>
              {settings.security === o.value && <Check size={15} className="ml-auto flex-none text-[#00ff41]" />}
            </button>
          ))}
        </div>

        <label className={`${labelCls} mt-5`}>On this device (local storage)</label>
        <div className="grid grid-cols-4 gap-2 text-center">
          <div className="rounded-xl border border-[#12351a] bg-black/40 py-2.5">
            <div className="font-mono text-lg font-extrabold text-[#00ff41]">{stats.bookmarks}</div>
            <div className="text-[10px] text-[#7fae8a]">SAVED SITES</div>
          </div>
          <div className="rounded-xl border border-[#12351a] bg-black/40 py-2.5">
            <div className="font-mono text-lg font-extrabold text-[#b26bff]">{stats.gallery}</div>
            <div className="text-[10px] text-[#7fae8a]">GALLERY</div>
          </div>
          <div className="rounded-xl border border-[#12351a] bg-black/40 py-2.5">
            <div className="font-mono text-lg font-extrabold text-[#00ff41]">{stats.history}</div>
            <div className="text-[10px] text-[#7fae8a]">HISTORY</div>
          </div>
          <div className="rounded-xl border border-[#12351a] bg-black/40 py-2.5">
            <div className="font-mono text-lg font-extrabold text-[#00ff41]">{stats.tabs}</div>
            <div className="text-[10px] text-[#7fae8a]">OPEN TABS</div>
          </div>
        </div>

        {!confirming ? (
          <button onClick={() => setConfirming(true)} className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl border border-[#ff5c7a]/50 py-3 text-sm font-bold text-[#ff5c7a] transition hover:bg-[#ff5c7a]/10">
            <Eraser size={15} /> Burn everything (panic wipe)
          </button>
        ) : (
          <div className="mt-5 rounded-xl border border-[#ff5c7a]/60 bg-[#ff5c7a]/5 p-3">
            <p className="text-sm font-bold text-[#ffb3c1]">Delete all tabs, saved sites, gallery media, history and identity from this device?</p>
            <div className="mt-3 flex gap-2">
              <button onClick={onClearAll} className="flex-1 rounded-lg bg-[#ff5c7a] py-2.5 text-sm font-extrabold text-black">YES, BURN IT ALL</button>
              <button onClick={() => setConfirming(false)} className="flex-1 rounded-lg border border-[#12351a] py-2.5 text-sm font-semibold text-[#d8ffe0]">Cancel</button>
            </div>
          </div>
        )}
        <p className="mt-3 text-center text-[11px] leading-relaxed text-[#51755c]">
          FreeOnion stores everything in your browser's local storage. Clearing your browser data also removes it.
        </p>
      </div>
    </Shell>
  );
}

export type { BookmarkItem };
