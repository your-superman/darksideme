import Image from "next/image";

/** FreeOnion logo (generated neon purple/green onion artwork). */
export function LogoMark({ size = 36, className = "" }: { size?: number; className?: string }) {
  return (
    <Image
      src="/icons/icon-512.png"
      alt="FreeOnion logo"
      width={size}
      height={size}
      className={`rounded-[26%] shadow-[0_0_18px_rgba(0,255,65,0.35),0_0_34px_rgba(157,0,255,0.25)] ${className}`}
      priority
    />
  );
}

export function Wordmark({ compact = false }: { compact?: boolean }) {
  return (
    <span className={`font-mono font-extrabold tracking-tight ${compact ? "text-base" : "text-lg"} leading-none`}>
      <span className="neon-text flicker">FREE</span>
      <span className="violet-text">ONION</span>
    </span>
  );
}

/** Small inline SVG onion used for .onion indicators. */
export function OnionGlyph({ size = 14, className = "" }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className} aria-hidden>
      <path d="M12 3c.6-1.1 1.6-1.8 2.8-2-.3 1.2-.9 2.1-1.9 2.7" stroke="#00ff41" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M12 21c-4.4 0-8-3.4-8-7.7C4 8.6 8.5 5.6 12 3c3.5 2.6 8 5.6 8 10.3 0 4.3-3.6 7.7-8 7.7Z" stroke="#b26bff" strokeWidth="1.6" />
      <path d="M12 18.2c-2.6 0-4.8-2.1-4.8-4.9 0-2.9 2.6-5 4.8-6.7 2.2 1.7 4.8 3.8 4.8 6.7 0 2.8-2.2 4.9-4.8 4.9Z" stroke="#00ff41" strokeWidth="1.4" />
      <circle cx="12" cy="13.4" r="1.6" fill="#00ff41" />
    </svg>
  );
}
