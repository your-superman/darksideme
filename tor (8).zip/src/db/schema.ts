import { pgTable, text, timestamp, integer, boolean, index } from "drizzle-orm/pg-core";

/** Websites saved by the user under a custom name. Synced with localStorage. */
export const bookmarks = pgTable(
  "bookmarks",
  {
    id: text("id").primaryKey(),
    name: text("name").notNull(),
    url: text("url").notNull(),
    folder: text("folder").notNull().default("Saved"),
    note: text("note").notNull().default(""),
    pinned: boolean("pinned").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("bookmarks_created_idx").on(t.createdAt)],
);

/** Browsing history recorded through the proxy. */
export const historyEntries = pgTable(
  "history_entries",
  {
    id: text("id").primaryKey(),
    title: text("title").notNull().default(""),
    url: text("url").notNull(),
    countryCode: text("country_code").notNull().default(""),
    exitIp: text("exit_ip").notNull().default(""),
    visitedAt: timestamp("visited_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("history_visited_idx").on(t.visitedAt)],
);

/** Media saved into the in-app Gallery (bytes live in on-device IndexedDB, metadata mirrored here). */
export const galleryItems = pgTable(
  "gallery_items",
  {
    id: text("id").primaryKey(),
    name: text("name").notNull(),
    kind: text("kind").notNull(), // image | video | gif
    mime: text("mime").notNull().default(""),
    sizeBytes: integer("size_bytes").notNull().default(0),
    sourceUrl: text("source_url").notNull(),
    pageUrl: text("page_url").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("gallery_created_idx").on(t.createdAt)],
);

/** Every generated Tor identity / circuit (audit log of IP + location changes). */
export const identities = pgTable(
  "identities",
  {
    id: text("id").primaryKey(),
    circuitId: text("circuit_id").notNull(),
    exitIp: text("exit_ip").notNull(),
    countryCode: text("country_code").notNull(),
    countryName: text("country_name").notNull(),
    city: text("city").notNull(),
    latencyMs: integer("latency_ms").notNull().default(0),
    torConnected: boolean("tor_connected").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("identities_created_idx").on(t.createdAt)],
);
