// Exit-node countries, cities and IP pools used by the identity engine.
// Each "New Identity" picks a guard -> middle -> exit circuit and a fresh
// exit IP inside the selected country's range.

export interface ExitCountry {
  code: string;
  name: string;
  cities: string[];
  /** first two octets of plausible ISP ranges in that country */
  ipPrefixes: string[];
  locale: string;
  timezone: string;
}

export const EXIT_COUNTRIES: ExitCountry[] = [
  { code: "NL", name: "Netherlands", cities: ["Amsterdam", "Rotterdam", "Utrecht", "The Hague"], ipPrefixes: ["185.107", "212.83", "89.38", "45.154"], locale: "nl-NL", timezone: "Europe/Amsterdam" },
  { code: "DE", name: "Germany", cities: ["Berlin", "Frankfurt", "Nuremberg", "Munich"], ipPrefixes: ["5.9", "88.198", "138.201", "78.46"], locale: "de-DE", timezone: "Europe/Berlin" },
  { code: "CH", name: "Switzerland", cities: ["Zurich", "Geneva", "Basel", "Lausanne"], ipPrefixes: ["179.43", "185.44", "84.17", "146.70"], locale: "de-CH", timezone: "Europe/Zurich" },
  { code: "SE", name: "Sweden", cities: ["Stockholm", "Gothenburg", "Malmo", "Lulea"], ipPrefixes: ["185.213", "45.83", "89.238", "193.32"], locale: "sv-SE", timezone: "Europe/Stockholm" },
  { code: "IS", name: "Iceland", cities: ["Reykjavik", "Keflavik", "Akureyri"], ipPrefixes: ["185.236", "82.221", "212.30", "89.17"], locale: "is-IS", timezone: "Atlantic/Reykjavik" },
  { code: "FR", name: "France", cities: ["Paris", "Roubaix", "Strasbourg", "Lyon"], ipPrefixes: ["51.15", "163.172", "62.210", "195.154"], locale: "fr-FR", timezone: "Europe/Paris" },
  { code: "US", name: "United States", cities: ["New York", "Ashburn", "Chicago", "San Jose"], ipPrefixes: ["23.129", "162.247", "199.249", "104.244"], locale: "en-US", timezone: "America/New_York" },
  { code: "CA", name: "Canada", cities: ["Toronto", "Montreal", "Vancouver"], ipPrefixes: ["159.203", "192.99", "158.69", "142.4"], locale: "en-CA", timezone: "America/Toronto" },
  { code: "GB", name: "United Kingdom", cities: ["London", "Manchester", "Edinburgh"], ipPrefixes: ["178.62", "46.101", "139.59", "88.80"], locale: "en-GB", timezone: "Europe/London" },
  { code: "JP", name: "Japan", cities: ["Tokyo", "Osaka", "Nagoya"], ipPrefixes: ["45.76", "149.28", "103.27", "202.182"], locale: "ja-JP", timezone: "Asia/Tokyo" },
  { code: "SG", name: "Singapore", cities: ["Singapore", "Jurong", "Tampines"], ipPrefixes: ["128.199", "139.59", "206.189", "159.65"], locale: "en-SG", timezone: "Asia/Singapore" },
  { code: "AU", name: "Australia", cities: ["Sydney", "Melbourne", "Perth"], ipPrefixes: ["45.63", "139.180", "103.86", "203.143"], locale: "en-AU", timezone: "Australia/Sydney" },
  { code: "BR", name: "Brazil", cities: ["Sao Paulo", "Rio de Janeiro", "Fortaleza"], ipPrefixes: ["177.93", "191.252", "45.225", "170.81"], locale: "pt-BR", timezone: "America/Sao_Paulo" },
  { code: "FI", name: "Finland", cities: ["Helsinki", "Espoo", "Tampere"], ipPrefixes: ["95.216", "65.21", "135.181", "78.27"], locale: "fi-FI", timezone: "Europe/Helsinki" },
  { code: "NO", name: "Norway", cities: ["Oslo", "Bergen", "Trondheim"], ipPrefixes: ["185.35", "91.229", "84.234", "77.88"], locale: "nb-NO", timezone: "Europe/Oslo" },
  { code: "AT", name: "Austria", cities: ["Vienna", "Graz", "Linz"], ipPrefixes: ["185.222", "146.0", "89.144", "193.239"], locale: "de-AT", timezone: "Europe/Vienna" },
  { code: "PL", name: "Poland", cities: ["Warsaw", "Krakow", "Gdansk"], ipPrefixes: ["185.38", "193.32", "94.152", "51.83"], locale: "pl-PL", timezone: "Europe/Warsaw" },
  { code: "CZ", name: "Czechia", cities: ["Prague", "Brno", "Ostrava"], ipPrefixes: ["185.87", "89.221", "46.28", "81.2"], locale: "cs-CZ", timezone: "Europe/Prague" },
  { code: "RO", name: "Romania", cities: ["Bucharest", "Cluj", "Timisoara"], ipPrefixes: ["89.47", "185.248", "45.148", "193.176"], locale: "ro-RO", timezone: "Europe/Bucharest" },
  { code: "LV", name: "Latvia", cities: ["Riga", "Daugavpils", "Liepaja"], ipPrefixes: ["185.22", "89.111", "46.166", "194.8"], locale: "lv-LV", timezone: "Europe/Riga" },
  { code: "UA", name: "Ukraine", cities: ["Kyiv", "Kharkiv", "Lviv"], ipPrefixes: ["185.67", "91.239", "46.148", "176.111"], locale: "uk-UA", timezone: "Europe/Kyiv" },
  { code: "MD", name: "Moldova", cities: ["Chisinau", "Balti"], ipPrefixes: ["185.108", "89.28", "195.178", "46.55"], locale: "ro-MD", timezone: "Europe/Chisinau" },
  { code: "ES", name: "Spain", cities: ["Madrid", "Barcelona", "Valencia"], ipPrefixes: ["185.61", "45.67", "89.36", "176.31"], locale: "es-ES", timezone: "Europe/Madrid" },
  { code: "IT", name: "Italy", cities: ["Milan", "Rome", "Turin"], ipPrefixes: ["185.125", "89.46", "45.93", "151.99"], locale: "it-IT", timezone: "Europe/Rome" },
];

const RELAY_NAMES = [
  "CalyxInstitute", "Quintex", "emeraldonion", "digineo1", "Artikel10", "F3Netze",
  "torserversNet", "Enkidu6", "hviv110", "NTHUCC", "PrivacyRepublic", "KoelnFreifunk",
  "DFRI", "Chalmers", "AccessNow", "Greenhost", "LeafNode", "onionpatch", "CryptoParty",
  "noiseTor", "OrNetQ", "Libertas", "VaultRelay", "NordicShield", "helvetia", "gustavo",
];

export interface CircuitHop {
  role: "Guard" | "Middle" | "Exit";
  name: string;
  ip: string;
  countryCode: string;
  countryName: string;
  city: string;
}

export interface Identity {
  circuitId: string;
  exitIp: string;
  countryCode: string;
  countryName: string;
  city: string;
  locale: string;
  timezone: string;
  latencyMs: number;
  hops: CircuitHop[];
  torConnected: boolean;
  via: string;
  createdAt: number;
}

function rand(min: number, max: number): number {
  return Math.floor(min + Math.random() * (max - min));
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function ipForCountry(country: ExitCountry): string {
  return `${pick(country.ipPrefixes)}.${rand(2, 250)}.${rand(2, 250)}`;
}

export function findCountry(code?: string | null): ExitCountry {
  if (code) {
    const found = EXIT_COUNTRIES.find((c) => c.code === code.toUpperCase());
    if (found) return found;
  }
  return pick(EXIT_COUNTRIES);
}

/** Build a fresh 3-hop circuit identity for the requested exit country. */
export function buildIdentity(countryCode?: string | null): Identity {
  const exit = findCountry(countryCode);
  const others = EXIT_COUNTRIES.filter((c) => c.code !== exit.code);
  const guardC = pick(others);
  const middleC = pick(others.filter((c) => c.code !== guardC.code));
  const exitIp = ipForCountry(exit);
  const names = [...RELAY_NAMES].sort(() => Math.random() - 0.5);

  return {
    circuitId: `C-${rand(1000, 9999)}-${rand(100, 999)}`,
    exitIp,
    countryCode: exit.code,
    countryName: exit.name,
    city: pick(exit.cities),
    locale: exit.locale,
    timezone: exit.timezone,
    latencyMs: rand(180, 920),
    hops: [
      { role: "Guard", name: names[0], ip: ipForCountry(guardC), countryCode: guardC.code, countryName: guardC.name, city: pick(guardC.cities) },
      { role: "Middle", name: names[1], ip: ipForCountry(middleC), countryCode: middleC.code, countryName: middleC.name, city: pick(middleC.cities) },
      { role: "Exit", name: names[2], ip: exitIp, countryCode: exit.code, countryName: exit.name, city: pick(exit.cities) },
    ],
    torConnected: false,
    via: "gateway",
    createdAt: Date.now(),
  };
}
