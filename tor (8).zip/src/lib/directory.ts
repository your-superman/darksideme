// Curated, well-known legitimate .onion services (news, privacy tools, search).
export interface DirectorySite {
  name: string;
  url: string;
  category: string;
  description: string;
}

export const DIRECTORY_SITES: DirectorySite[] = [
  {
    name: "DuckDuckGo",
    url: "https://duckduckgogg42xjoc72x3sjasowoarfbgcmvfimaftt6twagswzczad.onion/",
    category: "Search",
    description: "The privacy search engine's official onion service. Fast and reliable — a great first test.",
  },
  {
    name: "Ahmia Search",
    url: "http://juhanurmihxlp77nkq76byazcldy2hlmovfu2epvl5ankdibsot4csyd.onion/",
    category: "Search",
    description: "Search engine that indexes .onion services. Start here to find hidden services.",
  },
  {
    name: "Tor Project",
    url: "http://2gzyxa5ihm7nsggfxnu52rck2vv4rvmdlkiu3zzui5du4xyclen53wid.onion/",
    category: "Privacy",
    description: "Official Tor Project website as an onion service.",
  },
  {
    name: "BBC News",
    url: "https://www.bbcnewsd73hkzno2ini43t4gblxvycyac5aw4gnv7t2rccijh7745uqd.onion/",
    category: "News",
    description: "BBC's international news onion service for censored regions.",
  },
  {
    name: "The New York Times",
    url: "https://www.nytimesn7cgmftshazwhfgzm37qxb44r64ytbb2dj3x62d2lljsciiyd.onion/",
    category: "News",
    description: "NYTimes onion service for readers behind firewalls.",
  },
  {
    name: "ProPublica",
    url: "https://p53lf57qovyuvwsc6xnrppyply3vtqm7l6pcobkmyqsiofyeznfu5uqd.onion/",
    category: "News",
    description: "Pulitzer-winning investigative journalism nonprofit.",
  },
  {
    name: "Deutsche Welle",
    url: "https://www.dwndrbatfp3nazjqv57mhqrpk3b23uk25dycf7c6jtiufpenicitid.onion/",
    category: "News",
    description: "Germany's international broadcaster over Tor.",
  },
  {
    name: "SecureDrop Directory",
    url: "http://sdolvtfhatvsysc6l34d65ymdwxcujausv7k5jk4cy5ttzhjoi6fzvyd.onion/",
    category: "Whistleblowing",
    description: "Directory of newsroom SecureDrop whistleblower inboxes.",
  },
  {
    name: "Daniel's Hosting",
    url: "http://danielas3rtn54uwmofdo3x2bsdifr47huasnmbgqzfrec5ubupvtpid.onion/",
    category: "Tools",
    description: "Free shared hosting for onion services, chat and link lists.",
  },
  {
    name: "OnionShare Docs",
    url: "https://onionshare.org",
    category: "Tools",
    description: "Share files and host sites anonymously over Tor (clearnet docs).",
  },
  {
    name: "Privacy Guides",
    url: "https://www.privacyguides.org",
    category: "Privacy",
    description: "Community-vetted privacy tools and guides (clearnet).",
  },
  {
    name: "EFF Tor Guide",
    url: "https://ssd.eff.org",
    category: "Privacy",
    description: "Surveillance Self-Defense guides from the EFF (clearnet).",
  },
];

/** Normalize whatever the user pasted into a navigable URL (or search). */
export function normalizeInput(raw: string): string {
  const input = raw.trim();
  if (!input) return "";
  if (/^https?:\/\//i.test(input)) return input;
  // Looks like a domain / onion address
  if (/^[\w-]+(\.[\w-]+)+([/?#].*)?$/.test(input) && !input.includes(" ")) {
    return `http://${input}`;
  }
  // Treat as a search on Ahmia for onion terms, DuckDuckGo otherwise
  return `https://duckduckgo.com/html/?q=${encodeURIComponent(input)}`;
}

export function isOnionUrl(url: string): boolean {
  try {
    return new URL(url).hostname.endsWith(".onion");
  } catch {
    return /\.onion(\/|$|\?)/i.test(url);
  }
}

export function displayHost(url: string): string {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

/** Shorten long onion v3 addresses for tab titles: abcd1234…wxyz.onion */
export function shortOnion(host: string): string {
  if (!host.endsWith(".onion")) return host;
  const core = host.replace(/\.onion$/, "");
  const parts = core.split(".");
  const last = parts[parts.length - 1];
  if (last.length <= 18) return host;
  const prefix = parts.length > 1 ? parts.slice(0, -1).join(".") + "." : "";
  return `${prefix}${last.slice(0, 8)}…${last.slice(-4)}.onion`;
}
