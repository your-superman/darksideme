// On-device Gallery vault (IndexedDB). Media bytes never leave the device —
// downloads from web pages land here, auto-sorted into Images / Videos / GIFs.

export type MediaKind = "image" | "video" | "gif";

export interface GalleryRecord {
  id: string;
  name: string;
  kind: MediaKind;
  mime: string;
  size: number;
  sourceUrl: string;
  pageUrl: string;
  createdAt: number;
  blob: Blob;
}

const DB_NAME = "freeonion-gallery";
const STORE = "items";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        const store = db.createObjectStore(STORE, { keyPath: "id" });
        store.createIndex("createdAt", "createdAt");
        store.createIndex("sourceUrl", "sourceUrl");
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function tx<T>(mode: IDBTransactionMode, run: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORE, mode);
    const req = run(t.objectStore(STORE));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export function classifyKind(mime: string, url: string, fallback?: MediaKind): MediaKind {
  if (mime.startsWith("video/")) return "video";
  if (mime === "image/gif") return "gif";
  if (mime.startsWith("image/")) return "image";
  const clean = url.split(/[?#]/)[0].toLowerCase();
  if (/\.(mp4|webm|mov|m4v|ogv)$/.test(clean)) return "video";
  if (clean.endsWith(".gif")) return "gif";
  return fallback || "image";
}

export function nameFromUrl(url: string, kind: MediaKind): string {
  try {
    const u = new URL(url);
    const last = decodeURIComponent(u.pathname.split("/").filter(Boolean).pop() || "");
    if (last && last.includes(".")) return last.slice(0, 80);
    return `${u.hostname.replace(/^www\./, "")} ${kind}`;
  } catch {
    return `FreeOnion ${kind}`;
  }
}

export async function gallerySave(rec: Omit<GalleryRecord, "id" | "createdAt">): Promise<GalleryRecord> {
  const full: GalleryRecord = {
    ...rec,
    id: `gal-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
    createdAt: Date.now(),
  };
  await tx("readwrite", (s) => s.put(full));
  // Mirror metadata to the server vault (bytes stay on-device)
  fetch("/api/gallery", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      id: full.id, name: full.name, kind: full.kind, mime: full.mime,
      sizeBytes: full.size, sourceUrl: full.sourceUrl, pageUrl: full.pageUrl,
    }),
  }).catch(() => { /* offline is fine — IndexedDB is the source of truth */ });
  return full;
}

export async function galleryList(): Promise<GalleryRecord[]> {
  try {
    const all = await tx<GalleryRecord[]>("readonly", (s) => s.getAll());
    return (all || []).sort((a, b) => b.createdAt - a.createdAt);
  } catch {
    return [];
  }
}

export async function galleryCount(): Promise<number> {
  try {
    return await tx<number>("readonly", (s) => s.count());
  } catch {
    return 0;
  }
}

export async function galleryFindBySource(sourceUrl: string): Promise<GalleryRecord | null> {
  try {
    const all = await galleryList();
    return all.find((i) => i.sourceUrl === sourceUrl) || null;
  } catch {
    return null;
  }
}

export async function galleryDelete(id: string): Promise<void> {
  await tx("readwrite", (s) => s.delete(id));
  fetch(`/api/gallery?id=${encodeURIComponent(id)}`, { method: "DELETE" }).catch(() => {});
}

export async function galleryClear(): Promise<void> {
  try {
    await tx("readwrite", (s) => s.clear());
  } catch { /* ignore */ }
  fetch("/api/gallery", { method: "DELETE" }).catch(() => {});
}

/**
 * Download a media URL (through the FreeOnion proxy / Tor circuit) straight
 * into the on-device Gallery. Reports progress 0..1 when length is known.
 */
export async function downloadToGallery(
  sourceUrl: string,
  opts: { cc?: string; device?: string; pageUrl?: string; name?: string; kindHint?: MediaKind; onProgress?: (p: number | null) => void },
): Promise<GalleryRecord> {
  const proxyUrl = `/api/proxy?url=${encodeURIComponent(sourceUrl)}&cc=${opts.cc || "NL"}${opts.device === "android" ? "&device=android" : ""}`;
  const res = await fetch(proxyUrl);
  if (!res.ok) throw new Error(`Download failed (HTTP ${res.status})`);
  const mime = (res.headers.get("content-type") || "").split(";")[0].trim();
  if (mime === "text/html") throw new Error("That link returned a web page, not a media file.");

  const total = Number(res.headers.get("content-length") || 0);
  let blob: Blob;
  if (res.body && total > 0 && opts.onProgress) {
    const reader = res.body.getReader();
    const chunks: BlobPart[] = [];
    let received = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      if (value) {
        chunks.push(new Uint8Array(value));
        received += value.length;
        opts.onProgress(Math.min(1, received / total));
      }
    }
    blob = new Blob(chunks, { type: mime });
  } else {
    opts.onProgress?.(null);
    blob = await res.blob();
  }

  const kind = classifyKind(mime || blob.type, sourceUrl, opts.kindHint);
  return gallerySave({
    name: opts.name?.trim() || nameFromUrl(sourceUrl, kind),
    kind,
    mime: mime || blob.type,
    size: blob.size,
    sourceUrl,
    pageUrl: opts.pageUrl || "",
    blob,
  });
}

export function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / (1024 * 1024)).toFixed(1)} MB`;
  return `${(n / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}
