// Server-side Tor daemon manager.
// If a `tor` binary exists on the host, FreeOnion spawns it on demand
// (SocksPort 9050 + ControlPort 9051) so .onion sites load through the
// real Tor network. On hosts without tor, the proxy falls back to gateways.
import { spawn, type ChildProcess } from "node:child_process";
import fs from "node:fs";
import net from "node:net";

export const TOR_SOCKS_URL = process.env.TOR_PROXY || "socks5h://127.0.0.1:9050";
const DATA_DIR = "/tmp/freeonion-tor";

interface TorGlobal {
  child?: ChildProcess | null;
  starting?: Promise<boolean> | null;
  bootstrapped?: boolean;
  lastCheck?: { ok: boolean; at: number };
}
const g = globalThis as typeof globalThis & { __freeonionTor?: TorGlobal };
g.__freeonionTor = g.__freeonionTor || {};
const state = g.__freeonionTor;

function socksTarget(): { host: string; port: number } {
  try {
    const u = new URL(TOR_SOCKS_URL);
    return { host: u.hostname || "127.0.0.1", port: Number(u.port || 9050) };
  } catch {
    return { host: "127.0.0.1", port: 9050 };
  }
}

export function torSocksAlive(timeout = 800): Promise<boolean> {
  const now = Date.now();
  if (state.lastCheck && now - state.lastCheck.at < 15_000) return Promise.resolve(state.lastCheck.ok);
  const { host, port } = socksTarget();
  return new Promise((resolve) => {
    const sock = net.connect({ host, port });
    const done = (ok: boolean) => {
      state.lastCheck = { ok, at: Date.now() };
      sock.destroy();
      resolve(ok);
    };
    sock.setTimeout(timeout);
    sock.once("connect", () => done(true));
    sock.once("timeout", () => done(false));
    sock.once("error", () => done(false));
  });
}

function torBinary(): string | null {
  const candidates = [process.env.TOR_BINARY, "/usr/bin/tor", "/usr/local/bin/tor", "/opt/homebrew/bin/tor"].filter(Boolean) as string[];
  for (const c of candidates) {
    try {
      if (fs.existsSync(c)) return c;
    } catch { /* ignore */ }
  }
  return null;
}

async function waitFor(predicate: () => Promise<boolean>, timeoutMs: number, stepMs = 1000): Promise<boolean> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (await predicate()) return true;
    await new Promise((r) => setTimeout(r, stepMs));
  }
  return predicate();
}

/** Make sure a Tor daemon is running and bootstrapped. Returns true when ready. */
export function ensureTor(waitMs = 45_000): Promise<boolean> {
  if (state.bootstrapped) return torSocksAlive(400);
  if (state.starting) {
    return Promise.race([
      state.starting,
      new Promise<boolean>((resolve) => setTimeout(() => resolve(false), waitMs)),
    ]);
  }

  state.starting = (async () => {
    try {
      if (await torSocksAlive()) {
        state.bootstrapped = true;
        return true; // someone else's tor (system service / Tor Browser)
      }
      const bin = torBinary();
      if (!bin) return false;

      fs.mkdirSync(DATA_DIR, { recursive: true });
      const { port } = socksTarget();
      const child = spawn(
        bin,
        [
          "--SocksPort", String(port),
          "--ControlPort", "9051",
          "--CookieAuthentication", "0",
          "--DataDirectory", DATA_DIR,
          "--Log", "notice stdout",
          "--RunAsDaemon", "0",
        ],
        { stdio: ["ignore", "pipe", "pipe"] },
      );
      state.child = child;

      const onData = (chunk: Buffer) => {
        if (chunk.toString().includes("Bootstrapped 100%")) state.bootstrapped = true;
      };
      child.stdout?.on("data", onData);
      child.stderr?.on("data", onData);
      child.once("exit", () => {
        state.child = null;
        state.starting = null;
        state.bootstrapped = false;
        state.lastCheck = { ok: false, at: 0 };
      });

      // Tor is usable for onion lookups once bootstrapped; poll both signals.
      const ready = await waitFor(async () => {
        if (state.bootstrapped) return true;
        state.lastCheck = undefined;
        return (await torSocksAlive(500)) && Boolean(state.bootstrapped);
      }, 120_000, 1200);
      if (ready) state.bootstrapped = true;
      return ready;
    } catch {
      return false;
    }
  })().then((ok) => {
    // If tor isn't up, clear the cached attempt so a later call can retry
    // (e.g. after the binary gets installed) instead of being stuck on false.
    if (!ok && !state.child) state.starting = null;
    return ok;
  });

  return Promise.race([
    state.starting,
    new Promise<boolean>((resolve) => setTimeout(() => resolve(Boolean(state.bootstrapped)), waitMs)),
  ]);
}

/** Ask Tor for a fresh circuit (SIGNAL NEWNYM). Best effort. */
export function signalNewNym(): Promise<boolean> {
  return new Promise((resolve) => {
    const sock = net.connect({ host: "127.0.0.1", port: 9051 });
    let settled = false;
    const done = (ok: boolean) => {
      if (settled) return;
      settled = true;
      sock.destroy();
      resolve(ok);
    };
    sock.setTimeout(1500);
    sock.once("timeout", () => done(false));
    sock.once("error", () => done(false));
    sock.once("connect", () => sock.write("AUTHENTICATE\r\nSIGNAL NEWNYM\r\nQUIT\r\n"));
    let buf = "";
    sock.on("data", (d) => {
      buf += d.toString();
      if (buf.split("250").length >= 3) done(true);
    });
    sock.once("close", () => done(buf.includes("250")));
  });
}

export function torState(): "ready" | "bootstrapping" | "unavailable" {
  if (state.bootstrapped) return "ready";
  if (state.starting || state.child) return "bootstrapping";
  return torBinary() ? "bootstrapping" : "unavailable";
}
