import { NextRequest } from "next/server";
import http from "node:http";
import https from "node:https";
import { SocksProxyAgent } from "socks-proxy-agent";
import { findCountry, ipForCountry } from "@/lib/exitNodes";
import { ensureTor, TOR_SOCKS_URL } from "@/lib/torDaemon";
import { db } from "@/db";
import { historyEntries } from "@/db/schema";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export const maxDuration = 120;
const GATEWAY_SUFFIXES = [
  ".onion.ly",
  ".onion.pet",
  ".onion.dog",
  ".onion.city",
  ".onion.cab",
  ".onion.ws",
  ".onion.sh",
  ".onion.direct",
];

const UA_DESKTOP =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0";
const UA_ANDROID =
  "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.122 Mobile Safari/537.36";

interface FetchResult {
  status: number;
  contentType: string;
  body: Buffer;
  finalUrl: string;
  via: string;
}

/* ---------------------------------- fetchers ---------------------------------- */

function fetchViaAgent(
  urlStr: string,
  agent: http.Agent,
  headers: Record<string, string>,
  method: string,
  body: Buffer | null,
  redirects = 5,
): Promise<{ status: number; headers: http.IncomingHttpHeaders; body: Buffer; finalUrl: string }> {
  return new Promise((resolve, reject) => {
    const u = new URL(urlStr);
    const lib = u.protocol === "https:" ? https : http;
    const req = lib.request(
      {
        protocol: u.protocol,
        hostname: u.hostname,
        port: u.port || (u.protocol === "https:" ? 443 : 80),
        path: u.pathname + u.search,
        method,
        headers: { ...headers, host: u.host },
        agent,
        timeout: 45_000,
      },
      (res) => {
        const loc = res.headers.location;
        if (loc && res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && redirects > 0) {
          res.resume();
          const next = new URL(loc, urlStr).toString();
          resolve(fetchViaAgent(next, agent, headers, "GET", null, redirects - 1));
          return;
        }
        const chunks: Buffer[] = [];
        res.on("data", (c) => chunks.push(c as Buffer));
        res.on("end", () =>
          resolve({ status: res.statusCode || 502, headers: res.headers, body: Buffer.concat(chunks), finalUrl: urlStr }),
        );
      },
    );
    req.on("timeout", () => req.destroy(new Error("Tor request timed out")));
    req.on("error", reject);
    if (body) req.write(body);
    req.end();
  });
}

async function fetchDirect(
  urlStr: string,
  headers: Record<string, string>,
  method: string,
  body: Buffer | null,
  timeoutMs: number,
): Promise<FetchResult & { via: string }> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(urlStr, {
      method,
      headers,
      body: body && method !== "GET" && method !== "HEAD" ? new Uint8Array(body) : undefined,
      redirect: "follow",
      signal: ctrl.signal,
    });
    const buf = Buffer.from(await res.arrayBuffer());
    return {
      status: res.status,
      contentType: res.headers.get("content-type") || "application/octet-stream",
      body: buf,
      finalUrl: res.url || urlStr,
      via: "direct",
    };
  } finally {
    clearTimeout(t);
  }
}

/* ---------------------------------- rewriting ---------------------------------- */

function proxyUrl(absolute: string, cc: string, device = "desktop"): string {
  return `/api/proxy?url=${encodeURIComponent(absolute)}&cc=${cc}${device === "android" ? "&device=android" : ""}`;
}

function rewriteHtml(html: string, pageUrl: string, cc: string, via: string, device = "desktop"): string {
  const resolve = (rel: string): string | null => {
    if (!rel || rel.startsWith("data:") || rel.startsWith("javascript:") || rel.startsWith("mailto:") || rel.startsWith("#")) return null;
    try {
      const abs = new URL(rel, pageUrl);
      if (abs.protocol !== "http:" && abs.protocol !== "https:") return null;
      return abs.toString();
    } catch {
      return null;
    }
  };

  let out = html;

  // Drop CSP / existing base so our rewrites work
  out = out.replace(/<meta[^>]+http-equiv=["']?content-security-policy["']?[^>]*>/gi, "");
  out = out.replace(/<base[^>]*>/gi, "");

  // href / src / action / poster / background
  out = out.replace(
    /\b(href|src|action|poster|background|data-src)=("([^"]*)"|'([^']*)')/gi,
    (m, attr: string, _q: string, dq?: string, sq?: string) => {
      const val = dq ?? sq ?? "";
      const abs = resolve(val);
      if (!abs) return m;
      const realAttr = attr.toLowerCase() === "data-src" ? "src" : attr;
      const extra = attr.toLowerCase() === "href" ? ` data-fo-url="${abs.replace(/"/g, "&quot;")}"` : "";
      return `${realAttr}="${proxyUrl(abs, cc, device)}"${extra}`;
    },
  );

  // srcset
  out = out.replace(/\bsrcset=("([^"]*)"|'([^']*)')/gi, (m, _q: string, dq?: string, sq?: string) => {
    const val = dq ?? sq ?? "";
    const rewritten = val
      .split(",")
      .map((part) => {
        const [u, ...rest] = part.trim().split(/\s+/);
        const abs = u ? resolve(u) : null;
        return abs ? `${proxyUrl(abs, cc, device)} ${rest.join(" ")}`.trim() : part;
      })
      .join(", ");
    return `srcset="${rewritten}"`;
  });

  // url(...) in styles
  out = out.replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/gi, (m, _q: string, val: string) => {
    const abs = resolve(val);
    return abs ? `url("${proxyUrl(abs, cc, device)}")` : m;
  });

  const bridge = `<script>(function(){try{
var TARGET=${JSON.stringify(pageUrl)},VIA=${JSON.stringify(via)};
function post(t,d){try{parent.postMessage(Object.assign({source:"freeonion",type:t},d||{}),"*")}catch(e){}}
post("loaded",{url:TARGET,via:VIA,title:document.title});
new MutationObserver(function(){post("title",{title:document.title,url:TARGET})}).observe(document.querySelector("title")||document.documentElement,{subtree:true,characterData:true,childList:true});
function realUrl(u){try{if(!u||u.indexOf("data:")===0||u.indexOf("blob:")===0)return null;var x=new URL(u,location.href);var p=x.searchParams.get("url");if(p)return p;if(x.pathname.indexOf("/api/proxy")===0)return null;return new URL(u,TARGET).toString()}catch(_){return null}}
function mediaInfo(el){try{
  if(!el||!el.tagName)return null;
  if(el.tagName==="IMG"){var r=realUrl(el.currentSrc||el.src);if(!r)return null;return{kind:/\\.gif($|\\?)/i.test(r)?"gif":"image",url:r,name:(el.alt||"").slice(0,80)}}
  if(el.tagName==="VIDEO"){var s=el.currentSrc||el.src||"";if(!s){var so=el.querySelector("source[src]");s=so?so.src:""}var r2=realUrl(s);if(!r2)return null;return{kind:"video",url:r2,name:""}}
  return null}catch(_){return null}}
function sendMedia(el){var info=mediaInfo(el);if(!info)return false;var a=el.closest?el.closest("a[href]"):null;info.linkUrl=a?(a.getAttribute("data-fo-url")||realUrl(a.href)):null;info.pageUrl=TARGET;post("media",info);return true}
var chip=null,chipFor=null;
function ensureChip(){if(chip||!document.body)return;chip=document.createElement("div");chip.textContent="\\u2193 SAVE";chip.setAttribute("style","position:fixed;z-index:2147483647;display:none;padding:6px 12px;border-radius:999px;background:#00ff41;color:#000;font:700 12px/1 system-ui,sans-serif;letter-spacing:.06em;cursor:pointer;box-shadow:0 0 16px rgba(0,255,65,.55),0 4px 14px rgba(0,0,0,.45);user-select:none");chip.addEventListener("click",function(ev){ev.preventDefault();ev.stopPropagation();if(chipFor)sendMedia(chipFor);chip.style.display="none"},true);document.body.appendChild(chip)}
document.addEventListener("DOMContentLoaded",ensureChip);
document.addEventListener("mouseover",function(e){ensureChip();if(!chip)return;var m=e.target&&e.target.closest?(e.target.closest("img")||e.target.closest("video")):null;if(!m){if(e.target!==chip){chip.style.display="none";chipFor=null}return}var r=m.getBoundingClientRect();if(r.width<52||r.height<52){chip.style.display="none";return}chipFor=m;chip.style.display="block";chip.style.top=Math.max(6,r.top+8)+"px";chip.style.left=Math.max(6,r.right-84)+"px"},true);
document.addEventListener("scroll",function(){if(chip)chip.style.display="none"},true);
document.addEventListener("contextmenu",function(e){var m=e.target&&e.target.closest?(e.target.closest("img")||e.target.closest("video")):null;if(m&&mediaInfo(m)){e.preventDefault();sendMedia(m)}},true);
document.addEventListener("click",function(e){
  var m=e.target&&e.target.closest?(e.target.closest("img")||e.target.closest("video")):null;
  if(m&&mediaInfo(m)){
    if(m.tagName==="VIDEO"&&m.hasAttribute("controls")){/* let native controls work; SAVE chip handles download */}
    else{e.preventDefault();e.stopPropagation();sendMedia(m);return}
  }
  var a=e.target&&e.target.closest?e.target.closest("a[href]"):null;if(!a)return;
  var real=a.getAttribute("data-fo-url");
  if(!real){try{var u=new URL(a.href);real=u.searchParams.get("url")}catch(_){}}
  if(real&&/\\.(jpe?g|png|gif|webp|avif|bmp|svg|mp4|webm|mov|m4v)($|\\?)/i.test(real)&&!e.ctrlKey&&!e.metaKey){e.preventDefault();post("media",{kind:/\\.gif($|\\?)/i.test(real)?"gif":(/\\.(mp4|webm|mov|m4v)($|\\?)/i.test(real)?"video":"image"),url:real,name:(a.textContent||"").trim().slice(0,80),pageUrl:TARGET,linkUrl:null});return}
  if(real&&(a.target==="_blank"||e.ctrlKey||e.metaKey)){e.preventDefault();post("open-tab",{url:real});return}
  if(real){e.preventDefault();post("navigate",{url:real})}
},true);
document.addEventListener("submit",function(e){
  var f=e.target;if(!f||!f.action)return;
  try{var u=new URL(f.action,location.href);var real=u.searchParams.get("url")||f.getAttribute("action");
  if((f.method||"get").toLowerCase()==="get"&&real){e.preventDefault();var q=new URLSearchParams(new FormData(f)).toString();post("navigate",{url:real+(real.includes("?")?"&":"?")+q})}}catch(_){}
},true);
}catch(e){}})();</script>`;

  if (/<\/head>/i.test(out)) out = out.replace(/<\/head>/i, `${bridge}</head>`);
  else if (/<body[^>]*>/i.test(out)) out = out.replace(/<body[^>]*>/i, (m) => `${m}${bridge}`);
  else out = bridge + out;
  return out;
}

function rewriteCss(css: string, pageUrl: string, cc: string, device = "desktop"): string {
  return css.replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/gi, (m, _q: string, val: string) => {
    if (val.startsWith("data:")) return m;
    try {
      const abs = new URL(val, pageUrl).toString();
      return `url("${proxyUrl(abs, cc, device)}")`;
    } catch {
      return m;
    }
  });
}

function errorPage(target: string, attempts: { via: string; error: string }[]): string {
  const rows = attempts
    .map(
      (a) =>
        `<div style="display:flex;justify-content:space-between;gap:12px;padding:7px 10px;border:1px solid #12351a;border-radius:8px;margin-top:6px;background:#061208"><span style="color:#00ff41;font-weight:600">${a.via}</span><span style="color:#ff5c7a;text-align:right;word-break:break-word">${a.error}</span></div>`,
    )
    .join("");
  const isOnion = target.includes(".onion");
  return `<!doctype html><html><head><meta charset="utf-8"><title>FreeOnion — connection failed</title>
<style>body{background:#020403;color:#c9f5d2;font-family:ui-monospace,Menlo,Consolas,monospace;margin:0;padding:32px 18px}
.wrap{max-width:640px;margin:0 auto}.glow{color:#00ff41;text-shadow:0 0 18px rgba(0,255,65,.7)}
h1{font-size:22px}.url{color:#b26bff;word-break:break-all;font-size:13px}
.btn{display:inline-block;margin-top:14px;margin-right:8px;padding:9px 16px;border-radius:999px;border:1px solid #00ff41;color:#00ff41;background:rgba(0,255,65,.08);cursor:pointer;font:inherit}
.btn:hover{background:rgba(0,255,65,.2)}p{color:#7fae8a;font-size:13px;line-height:1.6}</style></head>
<body><div class="wrap">
<h1><span class="glow">FREEONION</span> — could not reach this site</h1>
<div class="url">${target.replace(/</g, "&lt;")}</div>
<p>${isOnion ? "This onion service did not answer through any gateway. It may be offline, overloaded, or the address may be wrong. Onion services come and go — try again, rebuild your circuit (New Identity), or verify the full 56-character v3 address." : "The website did not respond. It may be offline or blocking proxy traffic. Try again or rebuild your circuit with a new identity."}</p>
<div>${rows}</div>
<button class="btn" onclick="parent.postMessage({source:'freeonion',type:'reload'},'*')">Retry</button>
<button class="btn" onclick="parent.postMessage({source:'freeonion',type:'new-identity'},'*')">New identity &amp; retry</button>
<script>parent.postMessage({source:"freeonion",type:"error",url:${JSON.stringify(target)}},"*")</script>
</div></body></html>`;
}

/* ---------------------------------- handler ---------------------------------- */

async function handle(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const rawTarget = sp.get("url") || "";
  const cc = (sp.get("cc") || "NL").toUpperCase();
  const device = sp.get("device") === "android" ? "android" : "desktop";
  const isTop = sp.get("top") === "1";
  const country = findCountry(cc);

  let target: URL;
  try {
    target = new URL(rawTarget);
    if (target.protocol !== "http:" && target.protocol !== "https:") throw new Error("bad protocol");
  } catch {
    return new Response("Invalid URL", { status: 400 });
  }

  const method = req.method.toUpperCase();
  let body: Buffer | null = null;
  if (method !== "GET" && method !== "HEAD") {
    body = Buffer.from(await req.arrayBuffer());
  }

  const spoofIp = ipForCountry(country);
  const headers: Record<string, string> = {
    "user-agent": device === "android" ? UA_ANDROID : UA_DESKTOP,
    accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "accept-language": `${country.locale},en;q=0.7`,
    "x-forwarded-for": spoofIp,
    "x-real-ip": spoofIp,
    dnt: "1",
    "upgrade-insecure-requests": "1",
  };
  const ct = req.headers.get("content-type");
  if (ct && body) headers["content-type"] = ct;

  const isOnion = target.hostname.endsWith(".onion");
  const attempts: { via: string; error: string }[] = [];
  let result: FetchResult | null = null;

  if (isOnion) {
    // 1) Real Tor — auto-start the daemon if the binary exists on this host
    const torReady = await ensureTor(40_000);
    if (torReady) {
      // First attempt often just primes the hidden-service descriptor cache — retry once.
      for (let i = 0; i < 2 && !result; i++) {
        try {
          const agent = new SocksProxyAgent(TOR_SOCKS_URL);
          const r = await fetchViaAgent(target.toString(), agent, headers, method, body);
          result = {
            status: r.status,
            contentType: String(r.headers["content-type"] || "application/octet-stream"),
            body: r.body,
            finalUrl: r.finalUrl,
            via: "Real Tor network (SOCKS5 circuit)",
          };
        } catch (e) {
          attempts.push({ via: `Tor SOCKS5${i ? " (retry)" : ""}`, error: e instanceof Error ? e.message : "failed" });
        }
      }
    } else {
      attempts.push({ via: "Tor SOCKS5", error: "Tor daemon still bootstrapping — retry in ~30s for real Tor; trying gateways now" });
    }

    // 2) tor2web gateways
    if (!result) {
      for (const suffix of GATEWAY_SUFFIXES) {
        const gw = new URL(target.toString());
        // hostname is xxxx.onion ; gateway host is xxxx.onion.ly etc.
        gw.hostname = target.hostname + suffix.slice(".onion".length);
        gw.protocol = "https:";
        try {
          const r = await fetchDirect(gw.toString(), headers, method, body, 12_000);
          if (r.status >= 200 && r.status < 500 && r.body.length > 0) {
            result = { ...r, finalUrl: target.toString(), via: `Gateway ${suffix}` };
            break;
          }
          attempts.push({ via: `Gateway ${suffix}`, error: `HTTP ${r.status}` });
        } catch (e) {
          attempts.push({ via: `Gateway ${suffix}`, error: e instanceof Error ? e.name + ": network error" : "failed" });
        }
      }
    }
  } else {
    try {
      const r = await fetchDirect(target.toString(), headers, method, body, 20_000);
      result = { ...r, via: `Exit node ${country.code} (${spoofIp})` };
    } catch (e) {
      attempts.push({ via: "Direct via exit node", error: e instanceof Error ? e.message : "failed" });
    }
  }

  if (!result) {
    return new Response(errorPage(target.toString(), attempts), {
      status: 200,
      headers: { "content-type": "text/html; charset=utf-8", "x-freeonion-error": "1" },
    });
  }

  // Log top-level visits (best effort)
  if (isTop) {
    try {
      await db.insert(historyEntries).values({
        id: `h-${Date.now()}-${Math.floor(Math.random() * 1e6)}`,
        title: "",
        url: target.toString(),
        countryCode: country.code,
        exitIp: spoofIp,
      });
    } catch {
      /* history is best-effort */
    }
  }

  const contentType = result.contentType;
  const charsetMatch = /charset=([\w-]+)/i.exec(contentType);
  const decode = (buf: Buffer) => {
    try {
      return new TextDecoder(charsetMatch?.[1] || "utf-8").decode(buf);
    } catch {
      return new TextDecoder("utf-8").decode(buf);
    }
  };

  const baseHeaders: Record<string, string> = {
    "x-freeonion-via": result.via,
    "x-freeonion-target": target.toString(),
    "cache-control": "no-store",
  };

  if (/text\/html/i.test(contentType)) {
    const html = rewriteHtml(decode(result.body), result.finalUrl, country.code, result.via, device);
    return new Response(html, {
      status: 200,
      headers: { ...baseHeaders, "content-type": "text/html; charset=utf-8" },
    });
  }

  if (/text\/css/i.test(contentType)) {
    const css = rewriteCss(decode(result.body), result.finalUrl, country.code, device);
    return new Response(css, {
      status: result.status,
      headers: { ...baseHeaders, "content-type": "text/css; charset=utf-8" },
    });
  }

  return new Response(new Uint8Array(result.body), {
    status: result.status,
    headers: { ...baseHeaders, "content-type": contentType, "content-length": String(result.body.length) },
  });
}

export async function GET(req: NextRequest) {
  return handle(req);
}

export async function POST(req: NextRequest) {
  return handle(req);
}
