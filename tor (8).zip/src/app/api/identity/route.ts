import { NextRequest } from "next/server";
import { buildIdentity } from "@/lib/exitNodes";
import { ensureTor, signalNewNym, torSocksAlive, torState } from "@/lib/torDaemon";
import { db } from "@/db";
import { identities } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  // Warm up the Tor daemon in the background as soon as the app opens.
  void ensureTor(120_000);
  const torConnected = await torSocksAlive();
  let latest = null;
  try {
    const rows = await db.select().from(identities).orderBy(desc(identities.createdAt)).limit(1);
    latest = rows[0] ?? null;
  } catch {
    latest = null;
  }
  return Response.json({ torConnected, torState: torState(), latest });
}

export async function POST(req: NextRequest) {
  let countryCode: string | undefined;
  try {
    const body = await req.json();
    countryCode = typeof body?.countryCode === "string" ? body.countryCode : undefined;
  } catch {
    /* empty body is fine */
  }

  // Kick the daemon (no long block) and ask Tor for a brand-new circuit.
  void ensureTor(120_000);
  const newNym = await signalNewNym();
  const torConnected = newNym || (await torSocksAlive());

  const identity = buildIdentity(countryCode);
  identity.torConnected = torConnected;
  identity.via = torConnected ? "Real Tor circuit" : torState() === "bootstrapping" ? "Tor bootstrapping…" : "Onion gateway circuit";

  try {
    await db.insert(identities).values({
      id: `id-${Date.now()}-${Math.floor(Math.random() * 1e6)}`,
      circuitId: identity.circuitId,
      exitIp: identity.exitIp,
      countryCode: identity.countryCode,
      countryName: identity.countryName,
      city: identity.city,
      latencyMs: identity.latencyMs,
      torConnected,
    });
  } catch {
    /* logging is best-effort */
  }

  return Response.json({ identity, newNymSignalled: newNym, torState: torState() });
}
