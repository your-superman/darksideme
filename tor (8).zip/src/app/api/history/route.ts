import { NextRequest } from "next/server";
import { db } from "@/db";
import { historyEntries } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  try {
    const rows = await db.select().from(historyEntries).orderBy(desc(historyEntries.visitedAt)).limit(200);
    return Response.json({ history: rows });
  } catch {
    return Response.json({ history: [] });
  }
}

export async function DELETE(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  try {
    if (id) await db.delete(historyEntries).where(eq(historyEntries.id, id));
    else await db.delete(historyEntries);
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : "failed" }, { status: 500 });
  }
}
