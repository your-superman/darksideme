import { NextRequest } from "next/server";
import { db } from "@/db";
import { bookmarks } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  try {
    const rows = await db.select().from(bookmarks).orderBy(desc(bookmarks.createdAt)).limit(500);
    return Response.json({ bookmarks: rows });
  } catch {
    return Response.json({ bookmarks: [] });
  }
}

/** Create or update a single bookmark (upsert by id). */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, name, url, folder, note, pinned } = body ?? {};
    if (!name || !url) return Response.json({ error: "name and url are required" }, { status: 400 });
    const row = {
      id: typeof id === "string" && id ? id : `bm-${Date.now()}-${Math.floor(Math.random() * 1e6)}`,
      name: String(name).slice(0, 120),
      url: String(url).slice(0, 2048),
      folder: typeof folder === "string" && folder ? folder.slice(0, 60) : "Saved",
      note: typeof note === "string" ? note.slice(0, 300) : "",
      pinned: Boolean(pinned),
    };
    await db
      .insert(bookmarks)
      .values(row)
      .onConflictDoUpdate({
        target: bookmarks.id,
        set: { name: row.name, url: row.url, folder: row.folder, note: row.note, pinned: row.pinned },
      });
    return Response.json({ bookmark: row });
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : "failed" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  if (!id) return Response.json({ error: "id required" }, { status: 400 });
  try {
    await db.delete(bookmarks).where(eq(bookmarks.id, id));
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : "failed" }, { status: 500 });
  }
}
