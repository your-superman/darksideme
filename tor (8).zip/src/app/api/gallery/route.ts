import { NextRequest } from "next/server";
import { db } from "@/db";
import { galleryItems } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  try {
    const rows = await db.select().from(galleryItems).orderBy(desc(galleryItems.createdAt)).limit(500);
    return Response.json({ items: rows });
  } catch {
    return Response.json({ items: [] });
  }
}

/** Record gallery metadata (the media bytes stay in the device's IndexedDB vault). */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, name, kind, mime, sizeBytes, sourceUrl, pageUrl } = body ?? {};
    if (!sourceUrl || !kind) return Response.json({ error: "sourceUrl and kind are required" }, { status: 400 });
    const row = {
      id: typeof id === "string" && id ? id : `gal-${Date.now()}-${Math.floor(Math.random() * 1e6)}`,
      name: String(name || "media").slice(0, 160),
      kind: ["image", "video", "gif"].includes(kind) ? kind : "image",
      mime: String(mime || "").slice(0, 80),
      sizeBytes: Number.isFinite(Number(sizeBytes)) ? Number(sizeBytes) : 0,
      sourceUrl: String(sourceUrl).slice(0, 2048),
      pageUrl: String(pageUrl || "").slice(0, 2048),
    };
    await db.insert(galleryItems).values(row).onConflictDoNothing();
    return Response.json({ item: row });
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : "failed" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  try {
    if (id) await db.delete(galleryItems).where(eq(galleryItems.id, id));
    else await db.delete(galleryItems);
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : "failed" }, { status: 500 });
  }
}
