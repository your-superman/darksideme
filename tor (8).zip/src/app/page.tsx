"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Bookmark, Check, ChevronLeft, ChevronRight, Compass, Copy, Download, History as HistoryIcon,
  Home, Images as ImagesIcon, Loader2, Lock, MapPin, Monitor, Plus, RotateCw,
  Settings as SettingsIcon, Share2, Shuffle, Smartphone, Star, Wifi, WifiOff, X,
} from "lucide-react";
import { buildIdentity, type Identity } from "@/lib/exitNodes";
import { displayHost, isOnionUrl, normalizeInput, shortOnion } from "@/lib/directory";
import HomeScreen from "@/components/HomeScreen";
import LocationPanel from "@/components/LocationPanel";
import LibraryPanel from "@/components/LibraryPanel";
import GalleryPanel from "@/components/GalleryPanel";
import MediaViewer, { previewToViewerItem, type ViewerItem } from "@/components/MediaViewer";
import { galleryClear, galleryCount } from "@/lib/galleryStore";
import { InstallModal, SaveBookmarkModal, SettingsModal, type SaveDraft } from "@/components/Modals";
import { LogoMark, OnionGlyph, Wordmark } from "@/components/brand";
import {
  DEFAULT_SETTINGS, uid,
  type AppSettings, type BookmarkItem, type HistoryItem, type PanelTab, type TabState, type ToastMsg,
} from "@/components/types";

const LS = {
  tabs: "freeonion.tabs.v1",
  bookmarks: "freeonion.bookmarks.v1",
  history: "freeonion.history.v1",
  identity: "freeonion.identity.v1",
  settings: "freeonion.settings.v1",
};

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

function newTab(url = ""): TabState {
  return {
    id: uid("tab"),
    url,
    title: url ? shortOnion(displayHost(url)) : "New Tab",
    loading: Boolean(url),
    via: "",
    stack: url ? [url] : [],
    index: url ? 0 : -1,
    reloadKey: 0,
  };
}

function readLS<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

function writeLS(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch { /* storage full/blocked */ }
}

const LOADING_STEPS = [
  "Wrapping traffic in layer 1 encryption…",
  "Contacting guard relay…",
  "Extending circuit to middle relay…",
  "Exiting in your chosen country…",
  "Handshaking with the onion service…",
  "Decrypting response…",
];

export default function FreeOnionApp() {
  const [hydrated, setHydrated] = useState(false);
  const [tabs, setTabs] = useState<TabState[]>([]);
  const [activeTabId, setActiveTabId] = useState<string>("");
  const [address, setAddress] = useState("");
  const [identity, setIdentity] = useState<Identity | null>(null);
  const [identBusy, setIdentBusy] = useState(false);
  const [torConnected, setTorConnected] = useState(false);
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>([]);
  const [historyList, setHistoryList] = useState<HistoryItem[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [countdown, setCountdown] = useState(DEFAULT_SETTINGS.rotateSeconds);
  const [panel, setPanel] = useState<PanelTab | null>(null);
  const [toasts, setToasts] = useState<ToastMsg[]>([]);
  const [saveDraft, setSaveDraft] = useState<SaveDraft | null>(null);
  const [viewerItem, setViewerItem] = useState<ViewerItem | null>(null);
  const [galleryRefresh, setGalleryRefresh] = useState(0);
  const [galleryTotal, setGalleryTotal] = useState(0);
  const [showInstall, setShowInstall] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [installEvt, setInstallEvt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [online, setOnline] = useState(true);
  const [origin, setOrigin] = useState("");
  const [loadStep, setLoadStep] = useState(0);

  const iframeRef = useRef<HTMLIFrameElement | null>(null);
  const editingRef = useRef(false);
  const toastId = useRef(0);
  const identityRef = useRef<Identity | null>(null);
  identityRef.current = identity;

  const activeTab = useMemo(() => tabs.find((t) => t.id === activeTabId) || tabs[0], [tabs, activeTabId]);

  const toast = useCallback((title: string, body?: string, tone: ToastMsg["tone"] = "green") => {
    const id = ++toastId.current;
    setToasts((prev) => [...prev.slice(-3), { id, title, body, tone }]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 4200);
  }, []);

  /* ------------------------------ identity engine ------------------------------ */

  const applyIdentity = useCallback((idn: Identity, announce: boolean) => {
    setIdentity(idn);
    setTorConnected(idn.torConnected);
    writeLS(LS.identity, idn);
    setCountdown((prev) => prev); // countdown reset handled by caller via settings dep
    setCountdown(readRotateSeconds());
    setTabs((prev) => prev.map((t) => (t.id === activeTabId && t.url ? { ...t, reloadKey: t.reloadKey + 1, loading: true } : t)));
    if (announce) toast("New identity online", `${idn.city}, ${idn.countryName} · ${idn.exitIp} · ${idn.latencyMs} ms`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTabId, toast]);

  function readRotateSeconds(): number {
    const s = readLS<AppSettings>(LS.settings);
    return s?.rotateSeconds || DEFAULT_SETTINGS.rotateSeconds;
  }

  const newIdentity = useCallback(
    async (countryCode?: string, announce = true) => {
      setIdentBusy(true);
      try {
        const res = await fetch("/api/identity", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ countryCode: countryCode === "RANDOM" ? undefined : countryCode }),
        });
        if (!res.ok) throw new Error("identity failed");
        const data = (await res.json()) as { identity: Identity };
        applyIdentity(data.identity, announce);
      } catch {
        // Offline fallback — build circuit locally so the app never breaks.
        applyIdentity(buildIdentity(countryCode === "RANDOM" ? undefined : countryCode), announce);
      } finally {
        setIdentBusy(false);
      }
    },
    [applyIdentity],
  );

  /* ------------------------------ navigation ------------------------------ */

  const pushHistory = useCallback((url: string, title: string) => {
    setHistoryList((prev) => {
      if (prev[0]?.url === url) return prev;
      const next: HistoryItem[] = [
        { id: uid("h"), title, url, at: Date.now(), countryCode: identityRef.current?.countryCode || "" },
        ...prev,
      ].slice(0, 200);
      writeLS(LS.history, next);
      return next;
    });
  }, []);

  const navigateTab = useCallback(
    (tabId: string, rawUrl: string, opts?: { replace?: boolean }) => {
      const url = normalizeInput(rawUrl);
      if (!url) return;
      setTabs((prev) =>
        prev.map((t) => {
          if (t.id !== tabId) return t;
          const stack = opts?.replace ? [...t.stack.slice(0, t.index), url] : [...t.stack.slice(0, t.index + 1), url];
          return { ...t, url, title: shortOnion(displayHost(url)), loading: true, via: "", stack, index: stack.length - 1 };
        }),
      );
      setLoadStep(0);
      pushHistory(url, shortOnion(displayHost(url)));
    },
    [pushHistory],
  );

  const openInTab = useCallback(
    (url: string, inNewTab = false) => {
      const finalUrl = normalizeInput(url);
      if (!finalUrl) return;
      if (inNewTab || !activeTab) {
        const t = newTab(finalUrl);
        setTabs((prev) => [...prev, t]);
        setActiveTabId(t.id);
        pushHistory(finalUrl, shortOnion(displayHost(finalUrl)));
      } else {
        navigateTab(activeTab.id, finalUrl);
      }
      if (window.innerWidth < 1024) setPanel(null);
    },
    [activeTab, navigateTab, pushHistory],
  );

  const createTab = useCallback((url = "") => {
    const t = newTab(url ? normalizeInput(url) : "");
    setTabs((prev) => [...prev, t]);
    setActiveTabId(t.id);
    if (t.url) pushHistory(t.url, t.title);
  }, [pushHistory]);

  const closeTab = useCallback(
    (tabId: string) => {
      setTabs((prev) => {
        const idx = prev.findIndex((t) => t.id === tabId);
        const next = prev.filter((t) => t.id !== tabId);
        if (next.length === 0) {
          const t = newTab();
          setActiveTabId(t.id);
          return [t];
        }
        if (tabId === activeTabId) {
          const fallback = next[Math.min(idx, next.length - 1)];
          setActiveTabId(fallback.id);
        }
        return next;
      });
    },
    [activeTabId],
  );

  const goBack = useCallback(() => {
    if (!activeTab || activeTab.index <= 0) return;
    const url = activeTab.stack[activeTab.index - 1];
    setTabs((prev) => prev.map((t) => (t.id === activeTab.id ? { ...t, index: t.index - 1, url, loading: true, title: shortOnion(displayHost(url)) } : t)));
  }, [activeTab]);

  const goForward = useCallback(() => {
    if (!activeTab || activeTab.index >= activeTab.stack.length - 1) return;
    const url = activeTab.stack[activeTab.index + 1];
    setTabs((prev) => prev.map((t) => (t.id === activeTab.id ? { ...t, index: t.index + 1, url, loading: true, title: shortOnion(displayHost(url)) } : t)));
  }, [activeTab]);

  const reloadTab = useCallback(() => {
    if (!activeTab?.url) return;
    setLoadStep(0);
    setTabs((prev) => prev.map((t) => (t.id === activeTab.id ? { ...t, reloadKey: t.reloadKey + 1, loading: true } : t)));
  }, [activeTab]);

  const goHome = useCallback(() => {
    if (!activeTab) return;
    setTabs((prev) => prev.map((t) => (t.id === activeTab.id ? { ...t, url: "", title: "New Tab", loading: false, stack: [], index: -1, via: "" } : t)));
  }, [activeTab]);

  /* ------------------------------ bookmarks ------------------------------ */

  const persistBookmark = useCallback((b: BookmarkItem) => {
    fetch("/api/bookmarks", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(b),
    }).catch(() => { /* offline — localStorage is source of truth */ });
  }, []);

  const saveBookmark = useCallback(
    (draft: SaveDraft) => {
      const url = normalizeInput(draft.url);
      if (!url) return;
      setBookmarks((prev) => {
        let next: BookmarkItem[];
        if (draft.id) {
          next = prev.map((b) => (b.id === draft.id ? { ...b, name: draft.name, url, folder: draft.folder, note: draft.note, pinned: draft.pinned } : b));
          const updated = next.find((b) => b.id === draft.id);
          if (updated) persistBookmark(updated);
        } else {
          const created: BookmarkItem = {
            id: uid("bm"), name: draft.name, url, folder: draft.folder, note: draft.note, pinned: draft.pinned, createdAt: Date.now(),
          };
          next = [created, ...prev];
          persistBookmark(created);
        }
        writeLS(LS.bookmarks, next);
        return next;
      });
      setSaveDraft(null);
      toast(draft.id ? "Saved site updated" : "Website saved", `“${draft.name}” is in your on-device vault.`);
    },
    [persistBookmark, toast],
  );

  const deleteBookmark = useCallback((id: string) => {
    setBookmarks((prev) => {
      const next = prev.filter((b) => b.id !== id);
      writeLS(LS.bookmarks, next);
      return next;
    });
    fetch(`/api/bookmarks?id=${encodeURIComponent(id)}`, { method: "DELETE" }).catch(() => {});
  }, []);

  const isBookmarked = activeTab?.url ? bookmarks.some((b) => b.url === activeTab.url) : false;

  /* ------------------------------ hydrate ------------------------------ */

  useEffect(() => {
    setOrigin(window.location.origin);
    setOnline(navigator.onLine);

    const savedSettings = readLS<AppSettings>(LS.settings);
    if (savedSettings) {
      setSettings({ ...DEFAULT_SETTINGS, ...savedSettings });
      setCountdown(savedSettings.rotateSeconds || DEFAULT_SETTINGS.rotateSeconds);
    }

    const savedBookmarks = readLS<BookmarkItem[]>(LS.bookmarks) || [];
    setBookmarks(savedBookmarks);
    setHistoryList(readLS<HistoryItem[]>(LS.history) || []);

    const savedTabs = readLS<TabState[]>(LS.tabs);
    const params = new URLSearchParams(window.location.search);
    const paramUrl = params.get("url");

    let initialTabs: TabState[] = savedTabs && savedTabs.length > 0 ? savedTabs.map((t) => ({ ...t, loading: Boolean(t.url) })) : [newTab()];
    if (params.get("newtab")) initialTabs = [...initialTabs, newTab()];
    if (paramUrl) initialTabs = [...initialTabs, newTab(paramUrl)];
    setTabs(initialTabs);
    setActiveTabId(initialTabs[initialTabs.length - 1].id);

    if (params.get("saved")) setPanel("saved");
    if (params.get("gallery")) setPanel("gallery");
    galleryCount().then(setGalleryTotal).catch(() => {});

    const savedIdentity = readLS<Identity>(LS.identity);
    if (savedIdentity && !params.get("identity")) {
      setIdentity(savedIdentity);
      setTorConnected(savedIdentity.torConnected);
      // Refresh Tor-daemon status quietly (and again after bootstrap time)
      fetch("/api/identity").then((r) => r.json()).then((d) => setTorConnected(Boolean(d.torConnected))).catch(() => {});
      setTimeout(() => {
        fetch("/api/identity").then((r) => r.json()).then((d) => {
          if (d.torConnected) {
            setTorConnected(true);
            setIdentity((cur) => (cur ? { ...cur, torConnected: true, via: "Real Tor circuit" } : cur));
          }
        }).catch(() => {});
      }, 25_000);
    } else {
      void newIdentity(undefined, false);
    }
    if (params.get("identity")) setPanel("location");

    // Merge server-side bookmarks vault with local ones
    fetch("/api/bookmarks")
      .then((r) => r.json())
      .then((data) => {
        const remote = (data.bookmarks || []) as Array<Omit<BookmarkItem, "createdAt"> & { createdAt?: string }>;
        if (!remote.length) return;
        setBookmarks((prev) => {
          const byId = new Map(prev.map((b) => [b.id, b]));
          for (const r of remote) {
            if (!byId.has(r.id)) {
              byId.set(r.id, { ...r, createdAt: r.createdAt ? new Date(r.createdAt).getTime() : Date.now() });
            }
          }
          const merged = Array.from(byId.values()).sort((a, b) => b.createdAt - a.createdAt);
          writeLS(LS.bookmarks, merged);
          return merged;
        });
      })
      .catch(() => {});

    // PWA install state
    const standalone = window.matchMedia("(display-mode: standalone)").matches || ("standalone" in navigator && Boolean((navigator as unknown as { standalone?: boolean }).standalone));
    setIsInstalled(standalone);
    const onBIP = (e: Event) => {
      e.preventDefault();
      setInstallEvt(e as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setIsInstalled(true);
      setInstallEvt(null);
      toast("FreeOnion installed", "Find it on your home screen / app launcher. Free forever.");
    };
    window.addEventListener("beforeinstallprompt", onBIP);
    window.addEventListener("appinstalled", onInstalled);

    const onOnline = () => setOnline(true);
    const onOffline = () => setOnline(false);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);

    setHydrated(true);
    return () => {
      window.removeEventListener("beforeinstallprompt", onBIP);
      window.removeEventListener("appinstalled", onInstalled);
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* persist tabs/settings */
  useEffect(() => {
    if (hydrated && tabs.length) writeLS(LS.tabs, tabs.map((t) => ({ ...t, loading: false })));
  }, [tabs, hydrated]);

  useEffect(() => {
    if (hydrated) writeLS(LS.settings, settings);
  }, [settings, hydrated]);

  /* sync address bar */
  useEffect(() => {
    if (!editingRef.current) setAddress(activeTab?.url || "");
  }, [activeTab?.id, activeTab?.url]);

  /* loading step cycler + safety timeout */
  useEffect(() => {
    if (!activeTab?.loading) return;
    const stepTimer = setInterval(() => setLoadStep((s) => (s + 1) % LOADING_STEPS.length), 1400);
    const safety = setTimeout(() => {
      setTabs((prev) => prev.map((t) => (t.id === activeTab.id ? { ...t, loading: false } : t)));
    }, 45_000);
    return () => {
      clearInterval(stepTimer);
      clearTimeout(safety);
    };
  }, [activeTab?.loading, activeTab?.id, activeTab?.reloadKey, activeTab?.url]);

  /* auto-rotate identity */
  useEffect(() => {
    if (!hydrated || !settings.autoRotate) return;
    const t = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) {
          void newIdentity(settings.randomCountry ? undefined : identityRef.current?.countryCode);
          return settings.rotateSeconds;
        }
        return c - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [hydrated, settings.autoRotate, settings.rotateSeconds, settings.randomCountry, newIdentity]);

  useEffect(() => {
    setCountdown(settings.rotateSeconds);
  }, [settings.rotateSeconds]);

  /* switching Desktop <-> Android reloads the current page in the new mode */
  const deviceMode = settings.deviceMode;
  const prevDevice = useRef(deviceMode);
  useEffect(() => {
    if (!hydrated || prevDevice.current === deviceMode) return;
    const first = prevDevice.current;
    prevDevice.current = deviceMode;
    if (activeTab?.url) {
      setLoadStep(0);
      setTabs((prev) => prev.map((t) => (t.id === activeTab.id ? { ...t, loading: true, reloadKey: t.reloadKey + 1 } : t)));
    }
    toast(
      deviceMode === "android" ? "Android web app view" : "Desktop view",
      deviceMode === "android"
        ? "Websites now load their proper Android/mobile version in a phone frame."
        : "Websites now load their full desktop version.",
      first === deviceMode ? "green" : "green",
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [deviceMode, hydrated]);

  /* bridge messages from proxied pages */
  useEffect(() => {
    const onMsg = (e: MessageEvent) => {
      const d = e.data as {
        source?: string; type?: string; url?: string; title?: string; via?: string;
        kind?: "image" | "video" | "gif"; name?: string; pageUrl?: string; linkUrl?: string | null;
      } | null;
      if (!d || d.source !== "freeonion") return;
      if (iframeRef.current && e.source !== iframeRef.current.contentWindow) return;
      const tab = activeTab;
      if (!tab) return;
      if (d.type === "loaded") {
        setTabs((prev) => prev.map((t) => (t.id === tab.id ? { ...t, loading: false, via: d.via || t.via, title: d.title && d.title.trim() ? d.title.slice(0, 60) : t.title } : t)));
        if (d.title && tab.url) {
          setHistoryList((prev) => {
            const next = prev.map((h, i) => (i === 0 && h.url === tab.url ? { ...h, title: (d.title as string).slice(0, 80) } : h));
            writeLS(LS.history, next);
            return next;
          });
        }
      } else if (d.type === "title" && d.title) {
        setTabs((prev) => prev.map((t) => (t.id === tab.id && d.title ? { ...t, title: d.title.slice(0, 60) } : t)));
      } else if (d.type === "navigate" && d.url) {
        navigateTab(tab.id, d.url);
      } else if (d.type === "open-tab" && d.url) {
        openInTab(d.url, true);
      } else if (d.type === "reload") {
        reloadTab();
      } else if (d.type === "new-identity") {
        void newIdentity();
      } else if (d.type === "error") {
        setTabs((prev) => prev.map((t) => (t.id === tab.id ? { ...t, loading: false } : t)));
      } else if (d.type === "media" && d.url) {
        setViewerItem(
          previewToViewerItem({
            url: d.url,
            kind: d.kind || "image",
            name: d.name,
            pageUrl: d.pageUrl || tab.url,
            linkUrl: d.linkUrl ?? null,
          }),
        );
      }
    };
    window.addEventListener("message", onMsg);
    return () => window.removeEventListener("message", onMsg);
  }, [activeTab, navigateTab, openInTab, reloadTab, newIdentity]);

  /* install prompt trigger */
  const triggerInstall = useCallback(async () => {
    if (installEvt) {
      await installEvt.prompt();
      const choice = await installEvt.userChoice.catch(() => ({ outcome: "dismissed" as const }));
      if (choice.outcome === "accepted") setShowInstall(false);
      setInstallEvt(null);
    } else {
      setShowInstall(true);
    }
  }, [installEvt]);

  const shareCurrent = useCallback(async () => {
    if (!activeTab?.url) {
      toast("Nothing to share", "Open a website first.", "violet");
      return;
    }
    const link = `${window.location.origin}/?url=${encodeURIComponent(activeTab.url)}`;
    try {
      if (navigator.share) await navigator.share({ title: `FreeOnion — ${activeTab.title}`, url: link });
      else throw new Error("no share");
    } catch {
      try {
        await navigator.clipboard.writeText(link);
        toast("FreeOnion link copied", "Anyone opening it views this site inside FreeOnion.");
      } catch {
        toast("Copy this link", link, "violet");
      }
    }
  }, [activeTab, toast]);

  const panicWipe = useCallback(() => {
    Object.values(LS).forEach((k) => localStorage.removeItem(k));
    const t = newTab();
    setTabs([t]);
    setActiveTabId(t.id);
    setBookmarks([]);
    setHistoryList([]);
    setGalleryTotal(0);
    setGalleryRefresh((k) => k + 1);
    setShowSettings(false);
    void galleryClear();
    fetch("/api/history", { method: "DELETE" }).catch(() => {});
    void newIdentity(undefined, false);
    toast("Everything burned", "Tabs, saved sites, gallery, history and identity wiped from this device.", "violet");
  }, [newIdentity, toast]);

  const sandboxFor = (level: AppSettings["security"]) => {
    if (level === "safest") return "allow-forms";
    if (level === "safer") return "allow-scripts allow-forms allow-popups";
    return "allow-scripts allow-same-origin allow-forms allow-popups allow-modals allow-downloads";
  };

  const togglePanel = (tab: PanelTab) => setPanel((cur) => (cur === tab ? null : tab));

  const folders = useMemo(() => Array.from(new Set(bookmarks.map((b) => b.folder))), [bookmarks]);

  /* ------------------------------ splash ------------------------------ */

  if (!hydrated) {
    return (
      <div className="flex h-dvh flex-col items-center justify-center gap-4 bg-[#020403]">
        <LogoMark size={92} />
        <div className="font-mono text-2xl font-extrabold"><span className="neon-text flicker">FREE</span><span className="violet-text">ONION</span></div>
        <div className="flex items-center gap-2 text-xs text-[#7fae8a]">
          <Loader2 size={14} className="animate-spin text-[#00ff41]" /> Building your circuit…
        </div>
      </div>
    );
  }

  const iframeSrc = activeTab?.url
    ? `/api/proxy?url=${encodeURIComponent(activeTab.url)}&cc=${identity?.countryCode || "NL"}&top=1${settings.deviceMode === "android" ? "&device=android" : ""}`
    : null;

  return (
    <div className="crt relative flex h-dvh flex-col overflow-hidden bg-[#020403] font-sans">
      {/* ================= HEADER ================= */}
      <header className="relative z-20 flex items-center gap-2 border-b border-[#12351a] bg-[#040805]/95 px-2.5 py-2 sm:gap-3 sm:px-3">
        <div className="flex flex-none items-center gap-2">
          <LogoMark size={34} />
          <div className="hidden flex-col min-[420px]:flex">
            <Wordmark compact />
            <span className="text-[9px] font-semibold uppercase tracking-[0.22em] text-[#51755c]">onion viewer · free</span>
          </div>
        </div>

        <div className="mx-auto flex min-w-0 items-center gap-2">
          {identity && (
            <button
              onClick={() => togglePanel("location")}
              className="flex min-w-0 items-center gap-2 rounded-full border border-[#1d5c2c] bg-black/50 py-1.5 pl-2 pr-3 transition hover:border-[#00ff41]/70"
              title="Exit node — tap to change location"
            >
              <span className="relative flex-none">
                <span className="block h-2.5 w-2.5 rounded-full bg-[#00ff41] pulse-dot" />
              </span>
              <span className="flex-none rounded bg-[#9d00ff]/25 px-1.5 py-0.5 font-mono text-[10px] font-extrabold text-[#b26bff]">{identity.countryCode}</span>
              <span className="hidden truncate text-xs text-[#9dffb0] md:block">{identity.city}</span>
              <span className="truncate font-mono text-xs font-bold text-white">{identity.exitIp}</span>
              <span className="hidden flex-none font-mono text-[10px] text-[#51755c] lg:block">{identity.latencyMs}ms</span>
            </button>
          )}
          <button
            onClick={() => void newIdentity()}
            disabled={identBusy}
            className="glow-btn flex flex-none items-center gap-1.5 rounded-full bg-[#00ff41] px-3 py-1.5 text-xs font-extrabold text-black disabled:opacity-60"
            title="Burn this circuit and get a new IP + identity"
          >
            <Shuffle size={13} className={identBusy ? "animate-spin" : ""} />
            <span className="hidden sm:inline">NEW IP</span>
          </button>
        </div>

        {!isInstalled ? (
          <button onClick={() => setShowInstall(true)} className="flex flex-none items-center gap-1.5 rounded-full border border-[#9d00ff]/60 bg-[#9d00ff]/12 px-3 py-1.5 text-xs font-bold text-[#b26bff] transition hover:bg-[#9d00ff]/25">
            <Download size={13} /> <span className="hidden sm:inline">Install app</span><span className="sm:hidden">App</span>
          </button>
        ) : (
          <span className="hidden flex-none items-center gap-1 rounded-full border border-[#00ff41]/40 px-2.5 py-1.5 text-[10px] font-bold text-[#00ff41] min-[420px]:flex">
            <Check size={12} /> INSTALLED
          </span>
        )}
        <button onClick={() => setShowSettings(true)} className="flex-none rounded-full border border-[#12351a] p-2 text-[#7fae8a] transition hover:border-[#1d5c2c] hover:text-[#00ff41]" title="Settings & privacy">
          <SettingsIcon size={15} />
        </button>
      </header>

      {/* ================= TAB BAR ================= */}
      <div className="relative z-20 flex items-end gap-1 overflow-x-auto border-b border-[#12351a] bg-[#030603] px-2 pt-1.5">
        {tabs.map((t) => {
          const active = t.id === activeTab?.id;
          const onion = t.url ? isOnionUrl(t.url) : false;
          return (
            <div
              key={t.id}
              onClick={() => setActiveTabId(t.id)}
              className={`group flex max-w-[190px] flex-none cursor-pointer items-center gap-1.5 rounded-t-xl border border-b-0 px-2.5 py-2 text-xs transition ${
                active
                  ? "border-[#1d5c2c] bg-[#07130a] text-[#eaffef] shadow-[0_-4px_18px_rgba(0,255,65,0.12)]"
                  : "border-transparent text-[#7fae8a] hover:bg-[#050a06] hover:text-[#9dffb0]"
              }`}
              title={t.url || "New tab"}
            >
              {t.loading ? (
                <Loader2 size={13} className="flex-none animate-spin text-[#00ff41]" />
              ) : onion ? (
                <OnionGlyph size={14} className="flex-none" />
              ) : t.url ? (
                <Lock size={12} className="flex-none text-[#00ff41]" />
              ) : (
                <Plus size={13} className="flex-none text-[#00ff41]" />
              )}
              <span className="min-w-[52px] truncate font-medium">{t.title || "New Tab"}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  closeTab(t.id);
                }}
                className="flex-none rounded-md p-0.5 text-[#51755c] opacity-60 transition hover:bg-[#ff5c7a]/15 hover:text-[#ff5c7a] group-hover:opacity-100"
                title="Close tab"
              >
                <X size={12} />
              </button>
            </div>
          );
        })}
        <button onClick={() => createTab()} className="mb-1 flex-none rounded-lg border border-[#12351a] p-1.5 text-[#00ff41] transition hover:border-[#00ff41] hover:shadow-[0_0_10px_rgba(0,255,65,0.3)]" title="New tab">
          <Plus size={14} />
        </button>
        <span className="mb-2 ml-1 hidden flex-none font-mono text-[10px] text-[#51755c] sm:block">
          {tabs.length} tab{tabs.length === 1 ? "" : "s"} open · unlimited &amp; free
        </span>
      </div>

      {/* ================= TOOLBAR ================= */}
      <div className="relative z-20 flex items-center gap-1.5 border-b border-[#12351a] bg-[#040805] px-2 py-2 sm:px-3">
        <ToolBtn onClick={goBack} disabled={!activeTab || activeTab.index <= 0} title="Back">
          <ChevronLeft size={16} />
        </ToolBtn>
        <ToolBtn onClick={goForward} disabled={!activeTab || activeTab.index >= activeTab.stack.length - 1} title="Forward">
          <ChevronRight size={16} />
        </ToolBtn>
        <ToolBtn onClick={reloadTab} disabled={!activeTab?.url} title="Reload through circuit">
          <RotateCw size={14} className={activeTab?.loading ? "animate-spin" : ""} />
        </ToolBtn>
        <ToolBtn onClick={goHome} title="FreeOnion home">
          <Home size={15} />
        </ToolBtn>

        <form
          className="flex min-w-0 flex-1 items-center gap-2 rounded-full border border-[#1d5c2c] bg-black/60 px-3 py-2 transition focus-within:border-[#00ff41] focus-within:shadow-[0_0_16px_rgba(0,255,65,0.28)]"
          onSubmit={(e) => {
            e.preventDefault();
            editingRef.current = false;
            if (activeTab) navigateTab(activeTab.id, address);
            (e.target as HTMLFormElement).querySelector("input")?.blur();
          }}
        >
          {activeTab?.url && isOnionUrl(activeTab.url) ? (
            <OnionGlyph size={16} className="flex-none" />
          ) : activeTab?.url ? (
            <Lock size={13} className="flex-none text-[#00ff41]" />
          ) : (
            <OnionGlyph size={16} className="flex-none opacity-60" />
          )}
          <input
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            onFocus={(e) => {
              editingRef.current = true;
              e.target.select();
            }}
            onBlur={() => {
              editingRef.current = false;
              setAddress(activeTab?.url || "");
            }}
            placeholder="Paste any .onion link or website address…"
            className="min-w-0 flex-1 bg-transparent font-mono text-[13px] text-[#eaffef] outline-none placeholder:font-sans placeholder:text-[#51755c]"
            autoCapitalize="off"
            autoCorrect="off"
            spellCheck={false}
            enterKeyHint="go"
          />
          {activeTab?.url && isOnionUrl(activeTab.url) && (
            <span className="hidden flex-none rounded-full bg-[#9d00ff]/20 px-2 py-0.5 font-mono text-[9px] font-extrabold tracking-wider text-[#b26bff] min-[480px]:block">ONION</span>
          )}
        </form>

        <ToolBtn
          onClick={() => {
            if (!activeTab?.url) {
              toast("Nothing to save yet", "Open a website, then save it by name.", "violet");
              return;
            }
            setSaveDraft({ name: activeTab.title || displayHost(activeTab.url), url: activeTab.url, folder: "Saved", note: "", pinned: false });
          }}
          title="Save this website by name"
          active={isBookmarked}
        >
          <Star size={15} className={isBookmarked ? "fill-[#00ff41] text-[#00ff41]" : ""} />
        </ToolBtn>
        <ToolBtn onClick={() => void shareCurrent()} title="Copy a FreeOnion link to this page">
          <Share2 size={15} />
        </ToolBtn>

        <div className="mx-0.5 hidden h-6 w-px bg-[#12351a] sm:block" />

        <ToolBtn onClick={() => togglePanel("location")} title="Location & IP changer" active={panel === "location"}>
          <MapPin size={15} />
        </ToolBtn>
        <ToolBtn onClick={() => togglePanel("saved")} title="Saved websites" active={panel === "saved"}>
          <span className="relative">
            <Bookmark size={15} />
            {bookmarks.length > 0 && (
              <span className="absolute -right-2 -top-2 flex h-3.5 min-w-3.5 items-center justify-center rounded-full bg-[#00ff41] px-0.5 font-mono text-[8px] font-extrabold text-black">
                {bookmarks.length > 99 ? "99" : bookmarks.length}
              </span>
            )}
          </span>
        </ToolBtn>
        <ToolBtn onClick={() => togglePanel("explore")} title="Onion directory" active={panel === "explore"}>
          <Compass size={15} />
        </ToolBtn>
        <ToolBtn onClick={() => togglePanel("history")} title="History (on this device)" active={panel === "history"}>
          <HistoryIcon size={15} />
        </ToolBtn>
        <ToolBtn onClick={() => togglePanel("gallery")} title="My Gallery — images, videos & GIFs saved on this device" active={panel === "gallery"}>
          <span className="relative">
            <ImagesIcon size={15} />
            {galleryTotal > 0 && (
              <span className="absolute -right-2 -top-2 flex h-3.5 min-w-3.5 items-center justify-center rounded-full bg-[#9d00ff] px-0.5 font-mono text-[8px] font-extrabold text-white">
                {galleryTotal > 99 ? "99" : galleryTotal}
              </span>
            )}
          </span>
        </ToolBtn>

        <div className="mx-0.5 hidden h-6 w-px bg-[#12351a] sm:block" />

        {/* Desktop <-> Android web app view */}
        <div className="flex flex-none items-center rounded-full border border-[#1d5c2c] bg-black/60 p-0.5" title="Switch websites between Desktop and proper Android web app view">
          <button
            onClick={() => setSettings((s) => ({ ...s, deviceMode: "desktop" }))}
            className={`flex items-center gap-1 rounded-full px-2.5 py-1.5 text-[11px] font-bold transition ${settings.deviceMode === "desktop" ? "bg-[#00ff41] text-black shadow-[0_0_12px_rgba(0,255,65,0.4)]" : "text-[#7fae8a] hover:text-[#9dffb0]"}`}
          >
            <Monitor size={13} /> <span className="hidden xl:inline">Desktop</span>
          </button>
          <button
            onClick={() => setSettings((s) => ({ ...s, deviceMode: "android" }))}
            className={`flex items-center gap-1 rounded-full px-2.5 py-1.5 text-[11px] font-bold transition ${settings.deviceMode === "android" ? "bg-[#9d00ff] text-white shadow-[0_0_12px_rgba(157,0,255,0.45)]" : "text-[#7fae8a] hover:text-[#b26bff]"}`}
          >
            <Smartphone size={13} /> <span className="hidden xl:inline">Android</span>
          </button>
        </div>
      </div>

      {/* loading bar */}
      <div className="relative z-20 h-[3px] flex-none overflow-hidden bg-transparent">
        {activeTab?.loading && (
          <div className="loadbar absolute inset-y-0 w-2/5 bg-gradient-to-r from-transparent via-[#00ff41] to-[#9d00ff] shadow-[0_0_12px_rgba(0,255,65,0.8)]" />
        )}
      </div>

      {/* ================= MAIN ================= */}
      <div className="relative flex min-h-0 flex-1">
        <main className="relative min-w-0 flex-1 bg-black">
          {activeTab && !activeTab.url ? (
            <HomeScreen
              identity={identity}
              busy={identBusy}
              bookmarks={bookmarks}
              origin={origin}
              isInstalled={isInstalled}
              onOpenRaw={(input) => openInTab(input)}
              onOpen={(url, nt) => openInTab(url, nt)}
              onNewIdentity={() => void newIdentity()}
              onOpenPanel={(t) => setPanel(t)}
              onInstall={() => setShowInstall(true)}
              toast={toast}
            />
          ) : (
            <div className={settings.deviceMode === "android" ? "grid-bg flex h-full justify-center bg-[#020403] p-2 sm:p-3" : "h-full"}>
              <div
                className={
                  settings.deviceMode === "android"
                    ? "relative h-full w-[min(430px,100%)] overflow-hidden rounded-[30px] border-[5px] border-[#14532a] bg-white shadow-[0_0_50px_rgba(0,255,65,0.16),0_0_90px_rgba(157,0,255,0.12)]"
                    : "relative h-full w-full"
                }
              >
                {settings.deviceMode === "android" && (
                  <>
                    <span className="pointer-events-none absolute left-1/2 top-[7px] z-10 h-2.5 w-2.5 -translate-x-1/2 rounded-full border border-black/60 bg-[#0a0f0a] shadow-[inset_0_0_2px_rgba(0,255,65,0.7)]" />
                    <span className="pointer-events-none absolute bottom-[5px] left-1/2 z-10 h-1 w-24 -translate-x-1/2 rounded-full bg-black/35" />
                  </>
                )}
              {iframeSrc && activeTab && (
                <iframe
                  key={`${activeTab.id}-${activeTab.reloadKey}-${activeTab.url}-${settings.deviceMode}`}
                  ref={iframeRef}
                  src={iframeSrc}
                  title={activeTab.title}
                  sandbox={sandboxFor(settings.security)}
                  referrerPolicy="no-referrer"
                  className="h-full w-full bg-white"
                  onLoad={() => setTabs((prev) => prev.map((t) => (t.id === activeTab.id ? { ...t, loading: false } : t)))}
                />
              )}
              {activeTab?.loading && (
                <div className="pointer-events-none absolute inset-0 z-20 flex flex-col items-center justify-center gap-4 bg-[#020403]/92 backdrop-blur-[2px]">
                  <div className="relative">
                    <LogoMark size={74} />
                    <span className="absolute -inset-3 -z-10 rounded-full border border-[#00ff41]/30 spin-slow" style={{ borderTopColor: "#00ff41" }} />
                  </div>
                  <div className="px-4 text-center">
                    <p className="font-mono text-sm font-bold text-[#00ff41]">{LOADING_STEPS[loadStep]}</p>
                    <p className="mx-auto mt-1.5 max-w-md truncate font-mono text-[11px] text-[#b26bff]">{activeTab.url}</p>
                    <p className="mt-1 text-[11px] text-[#51755c]">Onion services can take 10–30 seconds. Hang tight.</p>
                  </div>
                </div>
              )}
              </div>
            </div>
          )}
        </main>

        {/* side panel — desktop inline / mobile overlay */}
        {panel && (
          <>
            <div className="fixed inset-0 z-30 bg-black/60 backdrop-blur-[1px] lg:hidden" onClick={() => setPanel(null)} />
            <aside className="fixed inset-y-0 right-0 z-40 flex w-[min(92vw,380px)] flex-col border-l border-[#1d5c2c] bg-[#030603] shadow-[-18px_0_40px_rgba(0,0,0,0.6)] lg:static lg:z-auto lg:w-[360px] lg:flex-none lg:shadow-none">
              <div className="flex items-center gap-1 border-b border-[#12351a] px-2.5 py-2">
                <PanelTabBtn active={panel === "location"} onClick={() => setPanel("location")} icon={<MapPin size={13} />} label="Location" />
                <PanelTabBtn active={panel === "saved"} onClick={() => setPanel("saved")} icon={<Bookmark size={13} />} label="Saved" />
                <PanelTabBtn active={panel === "explore"} onClick={() => setPanel("explore")} icon={<Compass size={13} />} label="Explore" />
                <PanelTabBtn active={panel === "history"} onClick={() => setPanel("history")} icon={<HistoryIcon size={13} />} label="History" />
                <PanelTabBtn active={panel === "gallery"} onClick={() => setPanel("gallery")} icon={<ImagesIcon size={13} />} label="Gallery" />
                <button onClick={() => setPanel(null)} className="ml-auto rounded-lg border border-[#12351a] p-1.5 text-[#7fae8a] hover:text-white" title="Close panel">
                  <X size={14} />
                </button>
              </div>
              <div className="min-h-0 flex-1 overflow-y-auto">
                {panel === "location" ? (
                  <LocationPanel
                    identity={identity}
                    busy={identBusy}
                    torConnected={torConnected}
                    settings={settings}
                    countdown={countdown}
                    onNewIdentity={(cc) => void newIdentity(cc)}
                    onSettings={setSettings}
                  />
                ) : panel === "gallery" ? (
                  <GalleryPanel
                    refreshKey={galleryRefresh}
                    cc={identity?.countryCode || "NL"}
                    device={settings.deviceMode}
                    onView={(item) => setViewerItem(item)}
                    onCountChange={setGalleryTotal}
                    toast={toast}
                  />
                ) : (
                  <LibraryPanel
                    tab={panel}
                    bookmarks={bookmarks}
                    history={historyList}
                    onOpen={(url, nt) => openInTab(url, nt)}
                    onSaveSite={(url, name) => setSaveDraft({ name, url, folder: "Saved", note: "", pinned: false })}
                    onEditBookmark={(b) => setSaveDraft({ id: b.id, name: b.name, url: b.url, folder: b.folder, note: b.note, pinned: b.pinned })}
                    onDeleteBookmark={deleteBookmark}
                    onTogglePin={(b) => {
                      const upd = { ...b, pinned: !b.pinned };
                      setBookmarks((prev) => {
                        const next = prev.map((x) => (x.id === b.id ? upd : x));
                        writeLS(LS.bookmarks, next);
                        return next;
                      });
                      persistBookmark(upd);
                      toast(upd.pinned ? "Pinned to home" : "Unpinned", `“${b.name}” ${upd.pinned ? "now shows" : "no longer shows"} on your speed-dial.`);
                    }}
                    onDeleteHistory={(id) => {
                      setHistoryList((prev) => {
                        const next = prev.filter((h) => h.id !== id);
                        writeLS(LS.history, next);
                        return next;
                      });
                      fetch(`/api/history?id=${encodeURIComponent(id)}`, { method: "DELETE" }).catch(() => {});
                    }}
                    onClearHistory={() => {
                      setHistoryList([]);
                      writeLS(LS.history, []);
                      fetch("/api/history", { method: "DELETE" }).catch(() => {});
                      toast("History burned", "No trace left on this device.", "violet");
                    }}
                  />
                )}
              </div>
            </aside>
          </>
        )}
      </div>

      {/* ================= STATUS BAR ================= */}
      <footer className="relative z-20 flex items-center gap-3 overflow-x-auto whitespace-nowrap border-t border-[#12351a] bg-[#040805] px-3 py-1.5 font-mono text-[10px] text-[#51755c]">
        <span className="flex items-center gap-1.5">
          {online ? <Wifi size={11} className="text-[#00ff41]" /> : <WifiOff size={11} className="text-[#ff5c7a]" />}
          {online ? "ONLINE" : "OFFLINE"}
        </span>
        {identity && (
          <>
            <span className="hidden sm:inline">
              CIRCUIT <span className="text-[#9dffb0]">{identity.hops.map((h) => h.countryCode).join(" → ")}</span>
            </span>
            <span>
              EXIT <span className="font-bold text-[#00ff41]">{identity.exitIp}</span> · {identity.city}, {identity.countryCode}
            </span>
          </>
        )}
        {activeTab?.via && <span className="hidden md:inline">VIA {activeTab.via}</span>}
        <span className="ml-auto flex items-center gap-3">
          {settings.autoRotate && (
            <span>
              AUTO-IP <span className="text-[#b26bff]">{Math.floor(countdown / 60)}:{String(countdown % 60).padStart(2, "0")}</span>
            </span>
          )}
          <span className="hidden items-center gap-1 sm:flex">
            {settings.deviceMode === "android" ? <Smartphone size={10} className="text-[#b26bff]" /> : <Monitor size={10} className="text-[#00ff41]" />}
            {settings.deviceMode === "android" ? "ANDROID VIEW" : "DESKTOP VIEW"}
          </span>
          <span className="hidden sm:inline">{bookmarks.length} saved · {galleryTotal} in gallery · local storage</span>
          <button
            className="flex items-center gap-1 font-bold text-[#00ff41] hover:underline"
            onClick={async () => {
              try {
                await navigator.clipboard.writeText(origin);
                toast("Live link copied", "Share it — FreeOnion installs free on any device.");
              } catch { /* noop */ }
            }}
          >
            <Copy size={10} /> LIVE LINK
          </button>
        </span>
      </footer>

      {/* ================= TOASTS ================= */}
      <div className="pointer-events-none fixed bottom-10 left-1/2 z-[80] flex w-[min(94vw,420px)] -translate-x-1/2 flex-col items-stretch gap-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`toast-in pointer-events-auto rounded-2xl border bg-[#040805]/97 px-4 py-3 shadow-2xl backdrop-blur ${
              t.tone === "violet" ? "border-[#9d00ff]/60 shadow-[0_0_24px_rgba(157,0,255,0.25)]" : t.tone === "red" ? "border-[#ff5c7a]/60" : "border-[#00ff41]/50 shadow-[0_0_24px_rgba(0,255,65,0.2)]"
            }`}
          >
            <div className={`text-sm font-extrabold ${t.tone === "violet" ? "text-[#b26bff]" : t.tone === "red" ? "text-[#ff5c7a]" : "text-[#00ff41]"}`}>{t.title}</div>
            {t.body && <div className="mt-0.5 text-xs leading-relaxed text-[#9dffb0]">{t.body}</div>}
          </div>
        ))}
      </div>

      {/* ================= MODALS ================= */}
      {saveDraft && <SaveBookmarkModal draft={saveDraft} folders={folders} onClose={() => setSaveDraft(null)} onSave={saveBookmark} />}
      {showInstall && (
        <InstallModal origin={origin} canPrompt={Boolean(installEvt)} onPromptInstall={() => void triggerInstall()} onClose={() => setShowInstall(false)} />
      )}
      {showSettings && (
        <SettingsModal
          settings={settings}
          stats={{ bookmarks: bookmarks.length, history: historyList.length, tabs: tabs.length, gallery: galleryTotal }}
          onSettings={setSettings}
          onClearAll={panicWipe}
          onClose={() => setShowSettings(false)}
        />
      )}
      {viewerItem && (
        <MediaViewer
          item={viewerItem}
          cc={identity?.countryCode || "NL"}
          device={settings.deviceMode}
          onClose={() => setViewerItem(null)}
          onSaved={() => {
            setGalleryRefresh((k) => k + 1);
            galleryCount().then(setGalleryTotal).catch(() => {});
          }}
          onDeleted={() => {
            setGalleryRefresh((k) => k + 1);
            galleryCount().then(setGalleryTotal).catch(() => {});
          }}
          onOpen={(url, nt) => {
            setViewerItem(null);
            openInTab(url, nt);
          }}
          onOpenGallery={() => {
            setViewerItem(null);
            setPanel("gallery");
          }}
          toast={toast}
        />
      )}
    </div>
  );
}

function ToolBtn({
  children, onClick, title, disabled = false, active = false,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  title: string;
  disabled?: boolean;
  active?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      className={`flex-none rounded-full border p-2 transition disabled:cursor-not-allowed disabled:opacity-30 ${
        active
          ? "border-[#00ff41] bg-[#00ff41]/12 text-[#00ff41] shadow-[0_0_12px_rgba(0,255,65,0.3)]"
          : "border-transparent text-[#7fae8a] hover:border-[#12351a] hover:bg-[#050a06] hover:text-[#00ff41]"
      }`}
    >
      {children}
    </button>
  );
}

function PanelTabBtn({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-1.5 rounded-full px-2.5 py-1.5 text-[11px] font-bold transition ${
        active ? "bg-[#00ff41] text-black shadow-[0_0_14px_rgba(0,255,65,0.35)]" : "text-[#7fae8a] hover:bg-[#050a06] hover:text-[#9dffb0]"
      }`}
    >
      {icon} {label}
    </button>
  );
}
