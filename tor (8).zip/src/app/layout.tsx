import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import Script from "next/script";
import "./globals.css";

export const metadata: Metadata = {
  title: "FreeOnion — Free Onion Website Viewer",
  description:
    "FreeOnion is a free onion (.onion) website viewer with multi-tab browsing, one-tap location & IP changer, auto circuit rotation and named bookmarks stored on your device. Install it as an app — 100% free.",
  applicationName: "FreeOnion",
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" }],
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "FreeOnion",
  },
  formatDetection: { telephone: false },
  openGraph: {
    title: "FreeOnion — Free Onion Website Viewer",
    description: "Paste any .onion link, browse in tabs, change your location & IP anywhere in the world. Free forever.",
    type: "website",
    images: [{ url: "/icons/icon-512.png", width: 512, height: 512 }],
  },
};

export const viewport: Viewport = {
  themeColor: "#020403",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#020403] text-[#d8ffe0] antialiased">
        {children}
        <Script id="freeonion-sw" strategy="afterInteractive">
          {`if ("serviceWorker" in navigator) {
            window.addEventListener("load", function () {
              navigator.serviceWorker.register("/sw.js").catch(function () {});
            });
          }`}
        </Script>
      </body>
    </html>
  );
}
